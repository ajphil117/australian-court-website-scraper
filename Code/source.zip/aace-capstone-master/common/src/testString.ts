const test: { thing: string } = {thing: "this is a test string!!!!"};

export interface Thingy {
    word: string;
    quantity: number;
}
export default test;