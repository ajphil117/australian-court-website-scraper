// Merges path objects and schemas (from api-docs/paths and /schemas) into a single
// OpenAPI document object, using openapi-doc.json as the base.
const fs = require('fs');
const path = require('path');

function mergeAPIDoc(addPaths = false) {
    const base = require('../api-docs/openapi.json');

    // Load all schemas
    let schemaPath = path.resolve(__dirname, '../api-docs/schemas');
    for (let fileName of fs.readdirSync(schemaPath)) {
        if (path.extname(fileName) === '.json') {
            let schema = require(path.resolve(schemaPath, fileName));
            base.components.schemas = {...base.components.schemas, ...schema };
        }
    }

    if (addPaths) {
        // Load all paths
        let pathPath = path.resolve(__dirname, '../api-docs/paths');
        for (let jsonPath of allJSONPaths(pathPath)) {
            let fromPaths = jsonPath.split(`paths${path.sep}`);
            let urlParts = fromPaths[fromPaths.length-1].split(path.sep); 
            let url = urlParts.join('/').slice(0, -'.json'.length);
           
            base.paths[url] = require(jsonPath);
        }
    }

    return base;
}

function allJSONPaths(dirPath) {
    let jsonPaths = [];
    for (let fileName of fs.readdirSync(dirPath)) {
        let fullPath = path.join(dirPath, fileName);
        if (path.extname(fileName) === '.json') {
            jsonPaths.push(fullPath);
        } else if (fs.lstatSync(fullPath).isDirectory()) {
            jsonPaths.push(...allJSONPaths(fullPath))
        }
    }
    return jsonPaths; 
}

module.exports = mergeAPIDoc;