const openAPICodegen = require('openapi-typescript-codegen');
const mergeAPIDoc = require('./MergeAPIDoc');
const path = require('path');


let doc = mergeAPIDoc(true);
openAPICodegen.generate({
    useUnionTypes: true,
    // The below property creates an AACEServer class we need to init, rather than a global singleton. We only have one API library at the moment, so the global object works fine for us.
    // clientName: "AACEServer",
    input: doc,
    output: path.resolve(__dirname, '../codegen/client')
});