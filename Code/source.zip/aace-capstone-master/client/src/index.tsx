import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import DashboardPage from './pages/DashboardPage';
import AuditorsPage from './pages/AuditorsPage';
import ManualSearchPage from './pages/ManualSearchPage';
import SettingsPage from './pages/SettingsPage';
import { OpenAPI } from '@aace/capstone-common/codegen/client';
import CaseDetailsPage from './pages/CaseDetailsPage';
import { CourtCase } from '@aace/capstone-common/codegen/client';
import LoginPage from './pages/LoginPage';
import { SnackbarProvider } from 'notistack';
import { StyledEngineProvider } from '@mui/material/styles';

if (process.env.NODE_ENV === 'development') {
  OpenAPI.BASE = 'http://localhost:3030/api/';
} else {
  OpenAPI.BASE = window.location.protocol + "//" + window.location.host + "/api/";
}

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <StyledEngineProvider injectFirst>
      <SnackbarProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<App />}>
              <Route path="" element={<DashboardPage />} />
              <Route path="auditors" element={<AuditorsPage />} />
              <Route path="search" element={<ManualSearchPage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="case" element={<CaseDetailsPage />} /> 
            </Route>
            <Route path="/login" element={<LoginPage />} />
          </Routes>
        </BrowserRouter>
      </SnackbarProvider>
    </StyledEngineProvider>
  </React.StrictMode>
);