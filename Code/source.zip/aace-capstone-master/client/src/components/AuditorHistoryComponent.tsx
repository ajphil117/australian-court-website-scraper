import { Auditor, CourtCase, CourtCaseWithReviews, DefaultService } from "@aace/capstone-common/codegen/client";
import { FolderOpen, PersonAddAlt } from "@mui/icons-material";
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import { Typography, IconButton } from "@mui/material";
import Button from '@mui/material/Button';
import Card from "@mui/material/Card";
import Divider from '@mui/material/Divider';
import { useCallback, useState } from 'react';
import styles from './auditorHistoryComponent.module.css';
import { detailsUrl } from "./CaseComponent";
import LazyList, { StaticItem } from './LazyList';
import SimplifiedCaseComponent from './SimplifiedCaseComponent';

type AuditorHistoryComponentProps = {
    auditor: Auditor,
    onClose?: () => void
}

function AuditorHistoryComponent(props: AuditorHistoryComponentProps) {
    const { auditor } = props;

    const fetchHistory = useCallback((offset: number, limit: number) => (
        DefaultService.getAuditorHistory(auditor.id, limit, offset)
    ), [auditor]);

    return (
        <div className={styles.historyBox}>

            {(props.auditor.givenNames || props.auditor.lastName) &&
                <div className={styles.auditorName}>
                    <PersonOutlineIcon className={styles.personIcon} />
                    <p className={styles.auditorNameText}>
                        {props.auditor.givenNames + ' ' + props.auditor.lastName}
                    </p>
                </div>
            }
            {props.auditor.organisation &&
                <div className={styles.auditorName}>
                    <WorkOutlineIcon className={styles.personIcon} />
                    <p>  {props.auditor.organisation}</p>
                </div>
            }
            {props.auditor.created &&
                <div className={styles.auditorName}>
                    <PersonAddAlt className={styles.personIcon} />
                    <p>Created on {new Date(props.auditor.created).toLocaleDateString()}</p>
                </div>
            }

            <Divider variant="middle" style={{ marginTop: '10px' }} />

            <div className={styles.historyContent}>
                <LazyList
                    fetch={fetchHistory}
                    itemSize={150} itemMargin={25} 
                    listItem={(style, index, c?: CourtCaseWithReviews) => <SimplifiedCaseComponent style={style} key={index} courtCase={c} />}
                />
            </div>

            <div className={styles.footer}>
                <Button onClick={props.onClose} variant="outlined">Close</Button>
            </div>

        </div>


    )

} export default AuditorHistoryComponent;