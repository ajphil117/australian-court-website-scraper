import { CourtCase } from '@aace/capstone-common/codegen/client';
import { FolderOpen } from '@mui/icons-material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import PeopleIcon from '@mui/icons-material/People';
import { IconButton, Skeleton } from '@mui/material';
import { Link } from 'react-router-dom';
import styles from './CaseComponent.module.css';

type CaseComponentProps = {
    courtCase?: CourtCase, style?: any,
    useExternalLink?: boolean
}

function CaseComponent(props: CaseComponentProps) {
    const { courtCase, useExternalLink } = props;

    return (

        <div className={styles.caseSquare} style={props.style}>
            <div className={styles.headerRow}>
                <div className={styles.iconStyleTop}>
                    <FolderOpen sx={{ fontSize: 30 }} color="primary" />
                </div>
                <div className={styles.titleContainer}>
                    {courtCase ? (
                        <h2 className={styles.titleText}><strong>#{courtCase?.id || ''}</strong> - {courtCase?.title || courtCase?.friendlyName || ''}</h2>
                    ) : (
                        <Skeleton style={{ width: '80%' }} />
                    )}
                </div>
                <div className={styles.headerDate}>
                    <p>{courtCase?.firstFound ? new Date(courtCase.firstFound).toDateString() : ''}</p>
                </div>
            </div>
            <div className={styles.headerRow}>
                <div className={styles.caseItem}>
                    <div className={styles.iconstyledetail}><PeopleIcon sx={{ fontSize: 15 }} color="action" /></div>
                </div>
                <div className={styles.caseItem} style={!courtCase ? {width: '100%'} : {}}>
                    {courtCase ? (
                        <p>{courtCase ? courtCase.parties.join(', ') : ''}</p>
                    ) : (
                        <Skeleton style={{ width: '50%' }} />
                    )}
                </div>
            </div>
            <div className={styles.headerRow}>
                <div className={styles.caseItem}>
                    <div className={styles.iconstyledetail}><LocationOnIcon sx={{ fontSize: 15 }} color="action" /> </div>
                </div>
                <div className={styles.caseItem} style={!courtCase ? {width: '100%'} : {}}>
                    {courtCase ? (
                        <p>{courtCase?.locationState}</p>
                    ) : (
                        <Skeleton style={{ width: '20%' }} />
                    )}
                </div>
            </div>

            <div className={styles.linkOverlay}>
                {useExternalLink ? (
                    <a href={courtCase ? courtCase.url : ''}><IconButton><OpenInNewIcon /></IconButton></a>
                ) : (
                    (courtCase ?
                        <Link to={detailsUrl(courtCase)}><IconButton><OpenInNewIcon /></IconButton></Link>
                        :
                        <IconButton><OpenInNewIcon /></IconButton>
                    )
                )}
            </div>

        </div>

    )
}
export default CaseComponent;

export function detailsUrl(c: CourtCase): string {
    return ("/case?id=" + encodeURIComponent(c.locationState + "." + c.id));
}