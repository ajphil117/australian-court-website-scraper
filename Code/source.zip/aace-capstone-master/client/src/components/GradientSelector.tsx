import { Shuffle } from '@mui/icons-material';
import { IconButton } from '@mui/material';
import { useState, useEffect } from 'react';
import { HSB, hsbToHex } from './colours';
import styles from './GradientSelector.module.css';

type GradientSelectorProps = {
    selectedIdx?: number, onSelected: (index: number, gradient: string[]) => void,
    nChoices?: number, shuffleKey?: number
    style?: any, className?: string
}
export default function GradientSelector(props: GradientSelectorProps) {
    const { nChoices, shuffleKey } = props;
    const [ grads, setGrads ] = useState<string[][]>([]);

    useEffect(function makeGradients() {
        setGrads(generateGradients(nChoices || 5));
    }, [ nChoices, shuffleKey ]);

    return (
        <div style={props.style} className={styles.root + (props.className && ( ' ' + props.className ))}>
            {grads.map((g, index) => (
                <button className={styles.gradient} key={g[0]+g[1]} onClick={() => props.onSelected(index, g)}
                    style={{ 
                        background: `linear-gradient(45deg, ${g[0]} 0%, ${g[1]} 100%)`,
                        outline: index === props.selectedIdx ? 'white 5px solid' : 'none'
                    }}
                />
            ))}
        </div>
    );
}

function generateGradients(n: number): string[][] {
    let g: string[][] = [];

    for (let i = 0; i < n; i++) {
        let h = Math.random() * 360;
        let s = 40 + (Math.random() * 50);
        let b = 94;
        let colourA = hsbToHex({ h: h, s: s, b: b }) 
        let colourB;

        let harmony = Math.random();
        if (harmony < 0.33) {
            // Complementary
            colourB = hsbToHex({
                h: (h + 180) % 360,
                s: plusOrMinus(s, 10, 40, 100),
                b: b
            });
        } else if (harmony < 0.66) {
            // Analogous
            colourB = hsbToHex({
                h: (h + (Math.random() > 0.5 ? 30 : -30 )) % 360,
                s: plusOrMinus(s, 5, 40, 100),
                b: b
            });
        } else {
            // Monochromatic
            colourB = hsbToHex({
                h: h,
                s: plusOrMinus(s, 25, 40, 100),
                b: b / 2
            });
        }

        g.push([ colourA, colourB ]);
    }
    return g;
}

function plusOrMinus(n: number, amount: number, lowerBound: number, upperBound: number) {
    let less = n - amount;
    let more = n + amount;
    if (less <= lowerBound) {
        return more;
    } else if (more >= upperBound) {
        return less;
    } else {
        return Math.random() > 0.5 ? more : less;
    }
}