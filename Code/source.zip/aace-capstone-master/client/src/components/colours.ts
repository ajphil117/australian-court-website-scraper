export function lerp(a: number, b: number, t: number) {
    return a + (b - a) * t;
}

export type RGB = { r: number, g: number, b: number };
export type HSB = { h: number, s: number, b: number };
// Courtesy of Jon Kantner via CSS-Tricks.com (https://css-tricks.com/converting-color-spaces-in-javascript/)
export function hexToRgb(h: string): RGB {
    let r = '', g = '', b = '';

    if (h.length === 4) {
        r = "0x" + h[1] + h[1];
        g = "0x" + h[2] + h[2];
        b = "0x" + h[3] + h[3];
    } else if (h.length === 7) {
        r = "0x" + h[1] + h[2];
        g = "0x" + h[3] + h[4];
        b = "0x" + h[5] + h[6];
    }

    return { r: +r, g: +g, b: +b };
}

export function rgbToHex(rgb: RGB): string {
    let { r, g, b }: any = rgb;
    
    r = Math.round(r).toString(16);
    g = Math.round(g).toString(16);
    b = Math.round(b).toString(16);
  
    if (r.length == 1)
      r = "0" + r;
    if (g.length == 1)
      g = "0" + g;
    if (b.length == 1)
      b = "0" + b;
  
    return "#" + r + g + b;
}

// Open source (multiple authors) via 30 seconds of code (https://www.30secondsofcode.org/js/s/rgb-to-hsb)
export function hsbToRgb(hsb: HSB): RGB {
    let { h, s, b } = hsb;
    s /= 100;
    b /= 100;
    const k = (n: number) => (n + h / 60) % 6;
    const f = (n: number) => b * (1 - s * Math.max(0, Math.min(k(n), 4 - k(n), 1)));
    return {r: 255 * f(5), g: 255 * f(3), b: 255 * f(1)};
};

export function hsbToHex(hsb: HSB): string {
    return rgbToHex(hsbToRgb(hsb));
}