import { CancelablePromise, PagedResponse } from "@aace/capstone-common/codegen/client";
import { useSnackbar } from "notistack";
import { useState, useEffect, forwardRef, useRef, useCallback } from "react";
import AutoSizer from "react-virtualized-auto-sizer";
import { FixedSizeList, VariableSizeList } from "react-window";
import InfiniteLoader from "react-window-infinite-loader";

export type ListItemRenderer<ItemType> = (style: any, index: number, item?: ItemType) => JSX.Element;
export type StaticItem<ItemType> = { index: number | ((list: ItemType[]) => number), item: ListItemRenderer<never>, size?: number, margin?: number };
export type ItemFetcher<ItemType> = (offset: number, limit: number) => CancelablePromise<PagedResponse & { items?: ItemType[] }>; 
type LazyListProps<ItemType> = {
    fetch: ItemFetcher<ItemType>, 
    itemSize: number, listItem: ListItemRenderer<ItemType>, itemMargin?: number,
    failText?: string, staticItems?: StaticItem<ItemType>[],
    minimumBatchSize?: number, fetchMoreThreshold?: number
};
export default function LazyList<ItemType>(props: LazyListProps<ItemType>) {
    const { fetch, failText, staticItems } = props;
    const { enqueueSnackbar } = useSnackbar();

    const inFlight = useRef<CancelablePromise<any> | null>(null);
    const [ items, setItems ] = useState<ItemType[]>([]);
    const [ totalItems, setTotalItems ] = useState<number>(props.minimumBatchSize || 10);

    const moreItems = (startIdx: number, endIdx: number, reset = false) => {
        if (reset) setItems([]);
        let req = fetch(startIdx, endIdx - startIdx + 1);
        inFlight.current = req;
        return req.then(page => {
            setTotalItems(page.total);
            if (page.items) {
                let newItems = reset ? [] : [ ...items ];
                // TODO: Splicing is *okay*, but it would be better to replace this with a
                // map-like structure that allows, for e.g., inserting at index 50 when only
                // 1-10 are currently known. If a user takes a long list and scrolls through
                // very rapidly, it's possible for this current implementation to insert array 
                // elements out of order.
                newItems.splice(page.offset, page.count, ...page.items);
                setItems(newItems);
                // Because the position of the StaticItems can change as the list expands, we need to reset
                // cached row heights when new items are added.
                if (staticItems && (infLoaderRef.current as any)._listRef.resetAfterIndex !== undefined) {
                    ((infLoaderRef.current as any)._listRef as VariableSizeList).resetAfterIndex(page.offset, false);
                }
            }
        }).catch(err => {
            if (err.name === 'CancelError') return;
            console.error(failText || 'Error fetching in LazyList', err);
            enqueueSnackbar(failText || 'An error occured while fetching the list', { variant: 'error' })
        }).finally(() => {
            inFlight.current = null;
        });
    }; 

    const infLoaderRef = useRef<InfiniteLoader>(null);
    const hasMountedRef = useRef(false);
    useEffect(function resetList() {
        if (hasMountedRef.current) {
            if (inFlight.current != null) {
                inFlight.current.cancel();
                inFlight.current = null;
            }

            if (infLoaderRef.current) {
                infLoaderRef.current.resetloadMoreItemsCache();
                moreItems(0, props.minimumBatchSize || 10, true);
            }
        }
        hasMountedRef.current = true;


        return () => {
            inFlight.current?.cancel();
        }
    }, [ fetch ])

    const itemSizeWithMargin = props.itemSize + (props.itemMargin || 0);

    // List is a copy of items[] with any StaticItems spliced in
    const list: (ItemType | StaticItem<ItemType>)[] = [ ...items ];
    let listToItemsIdx: (listIdx: number) => number = ((n) => n);
    const totalWithStatics = totalItems + (staticItems ? staticItems.length : 0);
    // StaticItems are allowed to specify their own sizes (this could be extended to all items, but not required)
    let ListComponent: any = FixedSizeList;
    let variableSizes = false;
    const getItemSize = (index: number) => {
        let i = list[index];
        if (isStaticItem<ItemType>(i)) {
            return i.size ? i.size + (i.margin || 0) : props.itemSize;
        } else {
            return itemSizeWithMargin;
        }
    }

    if (staticItems) {
        let itemsToListIdx: (itemsIdx: number) => number = ((n) => n);

        for (let sItem of staticItems) {
            let i = typeof sItem.index === 'number' ? sItem.index : sItem.index(items);
            let iActual = i < list.length ? i : list.length;
            list.splice(itemsToListIdx(i), 0, sItem);

            let lToI = listToItemsIdx.bind(null);
            listToItemsIdx = n => lToI(n >= iActual ? Math.max(n - 1, 0) : n);

            let iToL = itemsToListIdx.bind(null); 
            itemsToListIdx = n => iToL(n >= iActual ? Math.min(n + 1, list.length) : n);

            if (sItem.size !== undefined) variableSizes = true;
        }

        if (variableSizes) ListComponent = VariableSizeList;
    }

    const item = ({index, style}: { index: number, style: any}) => {
        let i = list[index];
        if (isStaticItem<ItemType>(i)) {
            let s = style;
            if (i.margin) {
                s = { 
                    ...style, 
                    height: i.size || props.itemSize,
                    marginTop: i.margin + 'px'
                };
            }
            return i.item(s, index); 
        } else {
            let s = style;
            if (props.itemMargin) {
                s = { 
                    ...style, 
                    height: props.itemSize,
                    marginTop: props.itemMargin + 'px'
                };
            }
            return props.listItem(s, index, items[listToItemsIdx(index)]);
        }
    }

    const isItemLoaded = (index: number) => {
        return index < list.length;
    }

    return (
        <AutoSizer>
            {({height, width}) => (
                <InfiniteLoader
                    isItemLoaded={isItemLoaded}
                    itemCount={totalWithStatics}
                    loadMoreItems={(s, e) => moreItems(listToItemsIdx(s), listToItemsIdx(e))}
                    ref={infLoaderRef}
                    minimumBatchSize={props.minimumBatchSize} threshold={props.fetchMoreThreshold}
                >
                    {({ onItemsRendered, ref }: any) => (
                        <ListComponent
                            itemSize={variableSizes ? getItemSize : itemSizeWithMargin}
                            itemCount={totalWithStatics}
                            outerElementType={NoTabDivComponent}
                            
                            ref={ref}
                            onItemsRendered={onItemsRendered}
                            height={height}
                            width={width}
                        >
                            {item}
                        </ListComponent>
                    )}
                </InfiniteLoader>
            )}
        </AutoSizer>
    )
}

function NoTabDiv(props: any, ref: any) {
    return <div ref={ref} {...props} tabIndex='-1' />
}
const NoTabDivComponent = forwardRef(NoTabDiv);

function isStaticItem<CastTo>(obj: any): obj is StaticItem<CastTo> {
    return obj != undefined && (typeof obj.index === 'number' || typeof obj.index === 'function') && typeof obj.item === 'function';
}