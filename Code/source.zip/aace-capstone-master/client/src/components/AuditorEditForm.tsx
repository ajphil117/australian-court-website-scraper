import { Auditor, AuditorPartial } from '@aace/capstone-common/codegen/client';
import { Button } from '@mui/material';
import { SelectChangeEvent } from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import { useEffect, useState } from 'react';
import styles from './AuditorEditForm.module.css';

const stateNames: {[shortName: string]: string} = {
    "QLD": "Queensland",
    "NSW": "New South Wales",
    "NT": "Northern Territory",
    "TAS": "Tasmania",
    "SA": "South Australia",
    "VIC": "Victoria",
    "ACT": "Australian Capital Territory",
    "WA": "Western Australia"
};

type AuditorEditFormProps = {
    onSubmit?: (auditor: AuditorPartial) => void,
    onDelete?: () => void,
    auditor?: Auditor,
    key?: string | number
};
export default function AuditorEditForm(props: AuditorEditFormProps) {
    const [givenNames, setGivenNames] = useState<string>('');
    const [lastName, setLastName] = useState<string>('');
    const [organisation, setOrganisation] = useState<string>('');
    const [states, setStates] = useState<string[]>([]);

    useEffect(function setFromExistingAuditor() {
        if (props.auditor) {
            setGivenNames(props.auditor.givenNames || '');
            setLastName(props.auditor.lastName || '');
            setOrganisation(props.auditor.organisation || '');
            setStates(props.auditor.approvedInStates || []);
        } else {
            setGivenNames('');
            setLastName('');
            setOrganisation('');
            setStates([]);
        }
    }, [ props.auditor, props.key ]);

    const handleChange = (event: SelectChangeEvent<string[]>) => {
        setStates(event.target.value as string[]);
    };

    const handleSubmit = () => {
        let a: AuditorPartial = {};
        if (givenNames.trim().length > 0) a.givenNames = givenNames;
        if (lastName.trim().length > 0) a.lastName = lastName;
        if (organisation.trim().length > 0) a.organisation = organisation;

        if (props.onSubmit) props.onSubmit(a);
    };

    return (
        <div className={styles.root}>
            <div className={styles.row}>
                <div className={styles.inputs}>
                    <TextField sx={{ width: '100%' }} label="Given names" variant="standard" value={givenNames} onChange={e => setGivenNames(e.target.value)} />
                </div>
                <div className={styles.inputs}>
                    <TextField sx={{ width: '100%' }} label="Last name" variant="standard" value={lastName} onChange={e => setLastName(e.target.value)} />
                </div>
            </div>

            <div className={styles.row}>
                <div className={styles.inputs}>
                    <TextField sx={{ width: '100%' }} label="Organization" variant="standard" value={organisation} onChange={e => setOrganisation(e.target.value)}  />
                </div>
            </div>

            <div className={styles.row}>
                <div className={styles.inputs}>
                    <Button sx={{ width: '100%' }} variant="contained" color="primary" aria-label="add" onClick={handleSubmit} disabled={organisation.trim().length === 0 && (givenNames.trim().length === 0 || lastName.trim().length === 0)}>
                        Submit
                    </Button>
                </div>
            </div>
            {(props.auditor && (
                <div className={styles.row}>
                    <div className={styles.inputs}>
                        <Button sx={{ width: '100%' }} variant="outlined" color="primary" aria-label="add" onClick={props.onDelete}>
                            Remove Auditor
                        </Button>
                    </div>
                </div>
            ))}
        </div>
    )
}