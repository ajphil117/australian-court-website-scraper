import { CourtCaseWithReviews, DefaultService, UserAccount } from "@aace/capstone-common/codegen/client";
import { FolderOpen, ReportProblemOutlined } from '@mui/icons-material';
import LaunchIcon from '@mui/icons-material/Launch';
import { Chip, IconButton } from '@mui/material';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import { detailsUrl } from './CaseComponent';
import styles from './simplifiedCaseComponent.module.css';
import UserIcon from "./UserIcon";

type SimplifiedCaseComponentProps = {
    courtCase?: CourtCaseWithReviews,
    style?: any
}
export default function SimplifiedCaseComponent(props: SimplifiedCaseComponentProps) {
    const { courtCase } = props;
    const navigate = useNavigate();
    const [ reviewer, setReviewer ] = useState<UserAccount | undefined>();

    useEffect(function fetchReviewerDetails() {
        if (courtCase && courtCase.reviews && courtCase.reviews.length > 0) {
            DefaultService.getUserById(courtCase.reviews[0].userId)
            .then(setReviewer)
            .catch(err => {
                console.error('Failed to fetch reviewer for case ' + courtCase.id, err);
            });
        }
    }, [ courtCase ]);

    let reviewedBy;
    if (courtCase && courtCase.reviews && courtCase.reviews.length > 0) {
        reviewedBy = (
            <span className={styles.reviewedBy}>
                <p>Reviewed by</p>
                <UserIcon height={38} fontSize={16} user={reviewer} />
                <p>{reviewer ? reviewer.name : ''}</p>
            </span>
        );
    } else {
        reviewedBy = (
          <Chip className="chip" icon={<ReportProblemOutlined />} label={"Pending review"} 
            color='warning'
          />
        )
    }

    return (
        <Card className={styles.root} style={props.style} variant="outlined">
            <div className={styles.icon}>
                <FolderOpen />
            </div>
            <div className={styles.caseDetails}>
                <Typography>
                    {courtCase ? new Date(courtCase.firstFound || '').toLocaleDateString() : ''}
                </Typography>
                <p className={styles.caseTitle}>
                    {courtCase ? ('#' + courtCase.id + ' - ' + (courtCase.title || courtCase.friendlyName)) : ''}
                </p>
                {reviewedBy}
            </div>
            <div className={styles.icon}>
                <IconButton onClick={courtCase ? () => navigate(detailsUrl(courtCase)) : () => {}}>
                    <LaunchIcon />
                </IconButton>
            </div>
        </Card>
    );
}
