import { UserAccount } from "@aace/capstone-common/codegen/client"
import React from "react";
import styles from './UserIcon.module.css';
import { hexToRgb, lerp } from "./colours";

const white = { r: 255, g: 255, b: 255 };
type UserIconProps = {
    user?: UserAccount,
    height?: string | number, fontSize?: string | number,
    onClick?: () => void
}
const UserIcon = React.forwardRef<HTMLDivElement, UserIconProps>((props, ref) => {
    let initials = '';
    if (props.user?.name) {
        let names = props.user.name.split(' ');
        if (names.length > 1) {
            initials = names[0].slice(0, 1) + names[names.length - 1].slice(0, 1);
        } else {
            initials = props.user.name.slice(0, 2);
        }
    }

    // Determine black/white text colour based on gradient colours
    let a = props.user?.colourA ? hexToRgb(props.user.colourA)! : white;
    let b = props.user?.colourB ? hexToRgb(props.user.colourB)! : white;
    let mid = { r: lerp(a.r, b.r, 0.5), g: lerp(a.g, b.g, 0.5), b: lerp(a.b, b.b, 0.5) };
    let midLinear: {[s: string]: number} = {};
    // Luminance calculation and w/b threshold per W3C guidelines (https://www.w3.org/TR/WCAG20/)
    for (let c in mid) {
        let l = (mid as any)[c] / 255;
        l = l <= 0.03928 ? l/12.92 : Math.pow((l + 0.055) / 1.055, 2.4);
        midLinear[c] = l;
    }
    let L = 0.2126 * midLinear.r + 0.7152 * midLinear.g + 0.0722 * midLinear.b;
    let textColour = L > 0.179 ? 'black' : 'white';

    let customHeight = null;
    if (props.height) {
        customHeight = {
            width: props.height, height: props.height,
            borderRadius: props.height
        }
    }

    return (
        <div className={styles.circle} onClick={props.onClick} ref={ref}
            style={{ background: props.user && `linear-gradient(45deg, ${props.user.colourA} 0%, ${props.user.colourB} 100%)`, 
            cursor: props.onClick ? 'pointer' : 'auto', ...customHeight }}>
            <p style={{ color: textColour, fontSize: props.fontSize }}>{initials}</p>
        </div>
    );
});
export default UserIcon;