import React, { useEffect, useRef, useState } from 'react';
import NavBar from './NavBar';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import styles from './App.module.css';
import UserIcon from './components/UserIcon';
import { DefaultService, OpenAPI, UserAccount } from '@aace/capstone-common/codegen/client';
import { List, ListItem, ListItemButton, ListItemIcon, ListItemText, Popover } from '@mui/material';
import { Logout } from '@mui/icons-material';

export const UserContext = React.createContext<UserAccount | undefined>(undefined);
const LOGIN_USER_SESSION_KEY = 'CurrentLoginUser';
const LOGIN_PASS_SESSION_KEY = 'CurrentLoginPass';

function App() {
  // Login and user account download
  const [ user, setUser ] = useState<UserAccount | undefined>(undefined);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(function getSignedInUser() {
    let username = OpenAPI.USERNAME as string | null;
    let pass = OpenAPI.PASSWORD as string | null;
    if (!username || !pass) {
      // Try get data from session state
      username = window.sessionStorage.getItem(LOGIN_USER_SESSION_KEY);
      pass = window.sessionStorage.getItem(LOGIN_PASS_SESSION_KEY);
    }

    if (!username || !pass) {
      // Not logged in
      navigate(`/login?to=${encodeURIComponent(location.pathname + location.search)}`, { replace: true });
    } else {
      OpenAPI.USERNAME = username;
      OpenAPI.PASSWORD = pass;
      // Fetch the UserAccount object from the server
      DefaultService.getUserById(username)
      .then(u => setUser(u))
      .catch(err => {
        console.error('Login failed', err);
        navigate(`/login?to=${encodeURIComponent(location.pathname)}`, { replace: true });
      });
    }

  }, [ navigate, location ]);
  
  useEffect(function storeLoginSession() {
    if (user) {
      window.sessionStorage.setItem(LOGIN_USER_SESSION_KEY, user.id);
      window.sessionStorage.setItem(LOGIN_PASS_SESSION_KEY, OpenAPI.PASSWORD as string);
    }
  }, [ user ]);

  // Logout popup menu
  const userIconRef = useRef<HTMLDivElement>(null); 
  const [ userMenuOpen, setUserMenuOpen ] = useState<boolean>(false);

  function logout() {
    setTimeout(() => {
      OpenAPI.USERNAME = '';
      OpenAPI.PASSWORD = '';
      window.sessionStorage.removeItem(LOGIN_USER_SESSION_KEY);
      window.sessionStorage.removeItem(LOGIN_PASS_SESSION_KEY);
      navigate('/login', { replace: true });
    }, 300);
  }

  return (
    <UserContext.Provider value={user}>
      <div className={styles.appRoot}>
        <NavBar />
        <div className={styles.content}>
          { pageTitles[location.pathname] && (
            <div className={styles.header}>
              <h1>{pageTitles[location.pathname]}</h1>
              <UserIcon height={'48px'} user={user} onClick={() => setUserMenuOpen(!userMenuOpen)} ref={userIconRef} />
              <Popover open={userMenuOpen}
                anchorEl={userIconRef.current}
                onClose={() => setUserMenuOpen(false)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
              >
                <List>
                  <ListItem disablePadding>
                    <ListItemButton onClick={logout}>
                      <ListItemIcon>
                        <Logout />
                      </ListItemIcon>
                      <ListItemText primary="Log out" />
                    </ListItemButton>
                  </ListItem>
                </List>
              </Popover>
            </div>
          )}

          <Outlet />
        </div>
      </div>
    </UserContext.Provider>
  );
}
export default App;

const pageTitles: {[s: string]: string}= {
  '/': 'Dashboard',
  '/auditors': 'Auditors',
  '/search': 'Manual search',
  '/settings': 'Settings'
}