import { DefaultService, OpenAPI, UserAccount, UserAccountPartial } from '@aace/capstone-common/codegen/client';
import { AccountCircle, ArrowForward, Clear, Logout, Mail, PersonAddAlt, Shuffle } from '@mui/icons-material';
import Search from '@mui/icons-material/Search';
import { Button, ButtonBase, IconButton, InputAdornment, ListItem, ListItemButton, TextField } from '@mui/material';
import { useSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import GradientSelector from '../components/GradientSelector';
import LazyList, { StaticItem } from '../components/LazyList';
import useDebounce from '../components/useDebounce';
import UserIcon from '../components/UserIcon';
import styles from './login.module.css';

export default function LoginPage() {
    const { enqueueSnackbar } = useSnackbar();
    const navigate = useNavigate();
    const location = useLocation();

    const [loading, setLoading] = useState<boolean>(false);
    const [signInStage, setSignInStage] = useState<keyof typeof stages>('pass');

    // Password
    const [password, setPassword] = useState<string>('');
    const [passwordWrong, setPasswordWrong] = useState<boolean>(false);

    async function tryGetUserList() {
        // User has entered a password, now make a dummy request to getUsersList to see if it's accepted
        if (loading) return;
        setLoading(true);
        OpenAPI.USERNAME = '?';
        OpenAPI.PASSWORD = password;
        try {
            await DefaultService.getUsersList();
            setSignInStage('user');
        } catch (err: any) {
            if (err.name === 'ApiError' && err.status === 401) {
                setPasswordWrong(true);
            } else {
                enqueueSnackbar("Couldn't contact server. Check your internet connection.", { 'variant': 'error' })
                console.error(err);
            }
        }
        setLoading(false);
    }

    function selectUser(u: UserAccount) {
        OpenAPI.USERNAME = u.id;
        let toUrl = '/';
        let q = new URLSearchParams(location.search);
        if (q.has('to')) {
            toUrl = q.get('to') as string;
        }
        navigate(toUrl, { replace: true });
    }

    async function createUser(u: UserAccountPartial) {
        if (loading) return;
        setLoading(true);
        try {
            let newUser = await DefaultService.postUser(u);
            selectUser(newUser);
            enqueueSnackbar('Created new user', { 'variant': 'success' });
        } catch (err: any) {
            enqueueSnackbar("Failed to create user - " + err.message || err.name, { 'variant': 'error' })
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    function logout() {
        setSignInStage('pass');
        setPassword('');
        OpenAPI.USERNAME = '?';
        OpenAPI.PASSWORD = '';
    }

    const stages = {
        'pass': <DepartmentPassword value={password} passwordWrong={passwordWrong}
            onSubmit={tryGetUserList} onChange={(s) => { setPassword(s); setPasswordWrong(false); }} loading={loading} />,
        'user': <UserSelect onSelect={selectUser} onCreateNew={() => setSignInStage('newUser')} />,
        'newUser': <NewUserForm onSubmit={createUser} onCancel={() => setSignInStage('user')} loading={loading} />
    }

    return (
        <div className={styles.root}>
            <div className={styles.content}>
                <div className={styles.header}>
                    <div className={styles.logo} />
                    <h1 className={styles.title}>AACE Court Watchdog</h1>
                </div>
                <div className={styles.body}>
                    {stages[signInStage]}
                </div>
                {signInStage !== 'pass' && (
                    <ButtonBase className={styles.logout} onClick={logout}>
                        <Logout fontSize='large' />
                        <h4>Log out</h4>
                    </ButtonBase>
                )}
            </div>
            <div className={styles.bg}></div>
        </div>
    );
}

type DepartmentPasswordProps = {
    value: string, onChange: (p: string) => void,
    passwordWrong: boolean, onSubmit: () => void, loading: boolean
};
function DepartmentPassword(props: DepartmentPasswordProps) {
    return (
        <>
            <h4>Enter department password to continue</h4>
            <TextField value={props.value} onChange={ev => props.onChange(ev.target.value)}
                onKeyUp={e => e.key === 'Enter' && props.onSubmit()}
                error={props.passwordWrong} helperText={props.passwordWrong && 'Incorrect password'}
                fullWidth label='Password' type='password' autoFocus />
            <Button variant='contained' onClick={() => props.onSubmit()} disabled={props.loading}>Sign in</Button>
        </>
    )
}

const fetchUsers = (offset: number, limit: number) =>
    DefaultService.getUsersList(limit, offset);
type UserSelectProps = {
    onSelect: (u: UserAccount) => void,
    onCreateNew: () => void
};
function UserSelect(props: UserSelectProps) {
    const UserListItem = (style: any, index: number, u?: UserAccount) => (
        <ListItem key={u?.id || index} disablePadding style={style}>
            <ListItemButton className={styles.userRow} onClick={ev => u && props.onSelect(u)}>
                <UserIcon user={u} />
                <p>{u?.name || u?.email || u?.id || 'User'}</p>
                <ArrowForward />
            </ListItemButton>
        </ListItem>
    );
    const NewUserItem = (style: any, index: number) => (
        <ListItem key={index} disablePadding style={style}>
            <ListItemButton className={styles.userRow} onClick={props.onCreateNew}>
                <div className={styles.circle}>
                    <PersonAddAlt fontSize='large' />
                </div>
                <p>Create new user</p>
            </ListItemButton>
        </ListItem>
    );

    const [nameSearch, setNameSearch] = useState<string>('');
    const [staticListItems, setStaticListItems] = useState<StaticItem<UserAccount>[] | undefined>([{ index: 0, item: NewUserItem }]);
    const nameSearchDebounced = useDebounce(nameSearch, 250);
    const [fetch, setFetch] = useState<{ f: any }>({ f: fetchUsers });

    useEffect(function updateFetchFunction() {
        if (nameSearchDebounced.length > 0) {
            let searchUsers = (offset: number, limit: number) =>
                DefaultService.getUsersList(limit, offset, nameSearchDebounced);
            setFetch({ f: searchUsers });
            setStaticListItems(undefined);
        } else {
            setFetch({ f: fetchUsers });
            setStaticListItems([{ index: 0, item: NewUserItem }]);
        }
    }, [nameSearchDebounced]);

    return (
        <>
            <h3 style={{ width: '100%' }}>Select your profile</h3>
            <TextField label='Profile search' variant='filled' autoFocus fullWidth
                value={nameSearch} onChange={ev => setNameSearch(ev.target.value)}
                InputProps={{
                    startAdornment: (
                        <InputAdornment position="start">
                            <Search />
                        </InputAdornment>
                    ),
                    endAdornment: nameSearch.length > 0 && (
                        <InputAdornment position="end">
                            <IconButton onClick={() => setNameSearch('')}>
                                <Clear />
                            </IconButton>
                        </InputAdornment>
                    )
                }} />
            <div className={styles.userList}>
                <LazyList fetch={fetch.f} itemSize={75} listItem={UserListItem} staticItems={staticListItems} />
            </div>
        </>
    )
}

type NewUserFormProps = {
    onSubmit: (u: UserAccountPartial) => void,
    onCancel: () => void, loading: boolean
}
function NewUserForm(props: NewUserFormProps) {
    const [ name, setName ] = useState<string>('');
    const [ nameError, setNameError ] = useState<boolean>(false);
    const [ email, setEmail ] = useState<string>('');

    const [gradIdx, setGradIdx] = useState<number | undefined>(undefined);
    const [gradColour, setGradColour] = useState<string[] | null>(null);
    const [gradShuffle, setGradShuffle] = useState<number>(0);
    const [gradError, setGradError] = useState<boolean>(false);

    function gradientSelected(index: number, colour: string[]) {
        setGradIdx(index);
        setGradColour(colour);
        setGradError(false);
    }

    function shuffleGrads() {
        setGradShuffle(gradShuffle + 1);
        setGradIdx(undefined);
        setGradColour(null);
    }

    function trySubmit() {
        let e = false;
        if (name.trim().length === 0) {
            setNameError(true);
            e = true;
        }
        if (gradColour === null) {
            setGradError(true);
            e = true;
        }

        if (!e) {
            props.onSubmit({
                name: name.trim(), email: email.trim().length > 0 ? email.trim() : undefined,
                colourA: gradColour![0], colourB: gradColour![1]
            });
        }
    }

    return (
        <>
            <h3 style={{ width: '100%', margin: 0 }}>New user profile</h3>
            <h4 style={{ width: '100%' }}>Enter your details</h4>
            <span className={styles.iconTextField}>
                <AccountCircle fontSize='large' />
                <TextField label='Name' fullWidth error={nameError} helperText={nameError && 'Name must not be blank'}
                    value={name} onChange={ev => { setName(ev.target.value); setNameError(false); }}
                />
            </span>
            <span className={styles.iconTextField}>
                <Mail fontSize='large' />
                <TextField label='Email address (optional)' fullWidth
                    value={email} onChange={ev => setEmail(ev.target.value)}
                />
            </span>

            <span className={styles.profileColourHeader}>
                <h4>Select a profile colour</h4>
                <IconButton onClick={shuffleGrads}>
                    <Shuffle />
                </IconButton>
            </span>
            <GradientSelector className={styles.profileColourSelect} shuffleKey={gradShuffle}
                selectedIdx={gradIdx} onSelected={gradientSelected} style={{ outline: gradError && 'red 1px solid' }}
            />
            {gradError && <p className={styles.errorText}>A profile colour must be selected</p>}
            <div className={styles.newUserButtons}>
                <Button variant='contained' style={{ marginRight: '15px' }} onClick={trySubmit} disabled={props.loading}> Submit</Button>
                <Button variant='outlined' onClick={props.onCancel}>Cancel</Button>
            </div>
        </>
    )
}