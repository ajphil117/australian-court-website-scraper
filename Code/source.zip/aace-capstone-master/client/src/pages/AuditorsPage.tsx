import { Auditor, AuditorPartial, DefaultService } from "@aace/capstone-common/codegen/client";
import { ArrowBack, Clear } from "@mui/icons-material";
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import HistoryIcon from '@mui/icons-material/History';
import SearchIcon from '@mui/icons-material/Search';
import { IconButton, InputAdornment, TablePagination, TextField } from "@mui/material";
import Button from "@mui/material/Button/Button";
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { useSnackbar } from "notistack";
import React, { useEffect } from "react";
import AuditorEditForm from "../components/AuditorEditForm";
import AuditorHistoryComponent from "../components/AuditorHistoryComponent";
import useDebounce from "../components/useDebounce";
import styles from './auditor.module.css';

export default function AuditorsPage() {
    const { enqueueSnackbar } = useSnackbar();

    const [auditors, setAuditors] = React.useState<Auditor[]>([]);
    const [totalAuditors, setTotalAuditors] = React.useState<number>(0);
    const [showSidebar, setShowSidebar] = React.useState<boolean>(false);
    const [sidebarPage, setSidebarPage] = React.useState<string>('');
    const [sidebarTargetAuditor, setSidebarTargetAuditor] = React.useState<Auditor | null>(null);
    const [sidebarEditKey, setSidebarEditKey] = React.useState<number>(0);

    const [tablePage, setTablePage] = React.useState<number>(0);
    const [rowsPerPage, setRowsPerPage] = React.useState<number>(25);

    const [ nameSearch, setNameSearch ] = React.useState<string>('');
    const nameSearchDebounced = useDebounce(nameSearch, 250);

    useEffect(function updateTable() {
        fetchAuditorPage();
    }, [tablePage, rowsPerPage, nameSearchDebounced]);

    function fetchAuditorPage() {
        DefaultService.getAuditorsList(rowsPerPage, tablePage * rowsPerPage, nameSearchDebounced.length > 0 ? nameSearchDebounced : undefined)
            .then(r => {
                setAuditors(r.items || []);
                setTotalAuditors(r.total);
            })
            .catch(err => console.error('Failed to fetch auditor list', err));
    }

    const handleEdit = (id: string) => {
        setSidebarPage('edit');
        setSidebarTargetAuditor(auditors.find(r => r.id === id)!);
        setShowSidebar(true);
    }

    const handleViewHistory = (id: string) => {
        setSidebarPage('history');
        setSidebarTargetAuditor(auditors.find(r => r.id === id)!);
        setShowSidebar(true);
    }

    const handleAddAuditor = () => {
        setSidebarPage('create');
        setSidebarTargetAuditor(null);
        setSidebarEditKey(sidebarEditKey + 1);
        setShowSidebar(true);
    }

    const createAuditor = (a: AuditorPartial) => {
        DefaultService.postAuditor(a)
            .then((a) => {
                enqueueSnackbar('Auditor profile created', { variant: 'success' });
                fetchAuditorPage();
                setShowSidebar(false);
            })
            .catch(err => { 
                console.error('Failed to create auditor', err);
                enqueueSnackbar('Failed to create auditor: ' + err.name, { variant: 'error' });
            });
    }

    const updateAuditor = (id: string, a: AuditorPartial) => {
        DefaultService.postAuditor({ id, ...a })
            .then((aNew) => {
                enqueueSnackbar('Auditor details updated', { variant: 'success' });
                fetchAuditorPage();
                setShowSidebar(false);
            })
            .catch(err => {
                console.error('Failed to update auditor', err);
                enqueueSnackbar('Failed to update auditor: ' + err.name, { variant: 'error' });
            });
    };

    const deleteAuditor = () => {
        if (!sidebarTargetAuditor) return;
        DefaultService.deleteAuditor({ id: sidebarTargetAuditor.id })
            .then(() => {
                enqueueSnackbar('Auditor profile deleted', { variant: 'success' });
                fetchAuditorPage();
                setShowSidebar(false);
            }).catch((err) => {
                enqueueSnackbar('Failed to delete auditor: ' + err.name, { variant: 'error' });
            });
    }

    let sidebarContent, sidebarTitle;
    switch (sidebarPage) {
        case 'history':
            sidebarTitle = 'History';
            sidebarContent = <AuditorHistoryComponent auditor={sidebarTargetAuditor!} onClose={() => setShowSidebar(false)} />;
            break;
        case 'edit':
            sidebarTitle = 'Edit auditor';
            sidebarContent = <AuditorEditForm auditor={sidebarTargetAuditor || undefined} 
                                onSubmit={a => updateAuditor(sidebarTargetAuditor!.id, a)} onDelete={deleteAuditor} />;
            break;
        case 'create':
            sidebarTitle = 'Create auditor';
            sidebarContent = <AuditorEditForm key={sidebarEditKey} onSubmit={createAuditor} />
            break;
    }

    return (
        <div className={styles.root}>
            <div className={styles.content}>
                <div className={styles.search}>
                    <div className={styles.searchBarContainer}>
                        {/* Searchbar  */}
                        <Paper
                            sx={{ display: 'flex', alignItems: 'center' }}
                        >
                            <TextField
                                value={nameSearch}
                                onChange={ev => setNameSearch(ev.target.value)}
                                sx={{ flex: 1 }}
                                placeholder="Search Auditors"
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon />
                                        </InputAdornment>
                                    ),
                                    endAdornment: nameSearch.length > 0 && (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setNameSearch('')}>
                                                <Clear />
                                            </IconButton>
                                        </InputAdornment>
                                    )
                                }}
                            />
                        </Paper>
                    </div>
                    {/* Add Auditor Button  */}
                    <div className={styles.buttonContainer}>
                        <Button className={styles.addAuditorBtn} variant="contained" onClick={handleAddAuditor} startIcon={<AddIcon />}>Add Auditor</Button>
                    </div>
                </div>

                {/*Table of Auditors currently added to the system */}
                <Paper className={styles.tablePaper}>
                    <TableContainer className={styles.tableContainer}>
                        <Table stickyHeader sx={{ minWidth: 650 }} aria-label="simple table" >
                            <TableHead>
                                <TableRow >
                                    <TableCell className={styles.tableHeader}>First Name</TableCell>
                                    <TableCell className={styles.tableHeader}>Last Name</TableCell>
                                    <TableCell className={styles.tableHeader}>Company Name </TableCell>
                                    <TableCell align="left"> </TableCell>
                                    <TableCell align="left"> </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {auditors.map((row) => (
                                    <TableRow
                                        key={row.id}
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                    >
                                        <TableCell align="left">{row.givenNames}</TableCell>
                                        <TableCell align="left">{row.lastName}</TableCell>
                                        <TableCell align="left">{row.organisation}</TableCell>
                                        {/*Edit button*/}
                                        <TableCell align="left">
                                            {<Button
                                                variant="outlined"
                                                onClick={() => handleEdit(row.id)}
                                                startIcon={<EditIcon />}
                                            >
                                                Edit
                                            </Button>}
                                        </TableCell>
                                        {/*View history button*/}
                                        <TableCell align="left">
                                            {<Button
                                                variant="outlined"
                                                onClick={() => handleViewHistory(row.id)}
                                                startIcon={<HistoryIcon />
                                                }
                                            >
                                                View History</Button>}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <TablePagination
                        component='div'
                        count={totalAuditors}
                        rowsPerPage={rowsPerPage} page={tablePage}
                        onPageChange={(ev, p) => setTablePage(p)}
                        onRowsPerPageChange={(ev) => setRowsPerPage(parseInt(ev.target.value))}
                    />
                </Paper>
            </div>

            <div className={styles.sidebarContainer} style={{
                pointerEvents: showSidebar ? 'all' : 'none', backgroundColor: `rgba(0, 0, 0, ${showSidebar ? '0.5' : '0'})`
            }} onClick={() => setShowSidebar(false)}>
                <div className={styles.sidebar} style={{ transform: `translateX(${showSidebar ? '0' : '100'}%)` }} onClick={(ev) => ev.stopPropagation()}>
                    <div className={styles.sidebarHeader}>
                        <IconButton className={styles.sidebarBack} onClick={() => setShowSidebar(false)}>
                            <ArrowBack />
                        </IconButton>
                        <h2>{sidebarTitle}</h2>
                    </div>
                    <div className={styles.sidebarContent}>
                        {sidebarContent}
                    </div>
                </div>
            </div>
        </div>
    )
}