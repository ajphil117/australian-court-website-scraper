import { CourtCase, DefaultService } from "@aace/capstone-common/codegen/client";
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import SearchIcon from '@mui/icons-material/Search';
import Box from '@mui/material/Box';
import Button from "@mui/material/Button/Button";
import Card from '@mui/material/Card';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Paper from '@mui/material/Paper';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import React from "react";
import CaseComponent from "../components/CaseComponent";
import LazyList, { ItemFetcher } from "../components/LazyList";
import styles from './search.module.css';


export default function ManualSearchPage() {

    const [type, setType] = React.useState<"person" | "org" | "number">("person");
    const [search, setSearch] = React.useState('');
    const [totalResults, setTotalResults] = React.useState<number | null>(null);
    const [fetchSearchResults, setFetchSearchResults] = React.useState<ItemFetcher<CourtCase> | null>(null);

    // Dropdown variable
    const handleChange = (event: SelectChangeEvent) => {
        setType(event.target.value as ("person" | "org" | "number"));
    };

    // Text/Input Base variable
    const handleSearch = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSearch(event.target.value);
    };

    // Search Button press
    const handleSubmit = (event: React.SyntheticEvent) => {
        let states = stateNames.filter((v, i) => checked[i]);
        setTotalResults(null);
        setFetchSearchResults(() => (offset: number, limit: number) => {
            let response = DefaultService.getManualSearch(
                search, type, undefined, states,
                limit, offset
            );
            response.then(res => {
                setTotalResults(res.total);
            }).catch(() => {});
            return response;
        });
    };

    // Filter Variables
    const stateNames = ["QLD", "NSW", "VIC", "WA", "SA", "ACT", "NT", "TAS"];
    const [checked, setChecked] = React.useState([true, true, true, true, true, true, true, true]);

    // All states
    const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([event.target.checked, event.target.checked, event.target.checked,
        event.target.checked, event.target.checked, event.target.checked,
        event.target.checked, event.target.checked, event.target.checked]);
    };
    // QLD
    const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([event.target.checked, checked[1], checked[2],
        checked[3], checked[4], checked[5],
        checked[6], checked[7]]);
    };
    // NSW
    const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([checked[0], event.target.checked, checked[2],
        checked[3], checked[4], checked[5],
        checked[6], checked[7]]);
    };
    // VIC
    const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([checked[0], checked[1], event.target.checked,
        checked[3], checked[4], checked[5],
        checked[6], checked[7]]);
    };
    // SA
    const handleChange6 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([checked[0], checked[1], checked[2],
        checked[3], event.target.checked, checked[5],
        checked[6], checked[7]]);
    };
    // ACT
    const handleChange7 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([checked[0], checked[1], checked[2],
        checked[3], checked[4], event.target.checked,
        checked[6], checked[7]]);
    };
    // NT
    const handleChange8 = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked([checked[0], checked[1], checked[2],
        checked[3], checked[4], checked[5],
        event.target.checked, checked[7]]);
    };

    // Filter Checkboxes
    const children = (
        <Box sx={{ display: 'inline', flexDirection: 'row', ml: 3 }}>
            <FormControlLabel
                label="QLD"
                control={<Checkbox checked={checked[0]} onChange={handleChange2} />}
            />
            <FormControlLabel
                label="NSW"
                control={<Checkbox checked={checked[1]} onChange={handleChange3} />}
            />
            <FormControlLabel
                label="VIC"
                control={<Checkbox checked={checked[2]} onChange={handleChange4} />}
            />
            <FormControlLabel
                label="WA"
                control={<Checkbox disabled />} //checked={checked[3]} onChange={handleChange5} />} 
            />
            <FormControlLabel
                label="SA"
                control={<Checkbox checked={checked[4]} onChange={handleChange6} />}
            />
            <FormControlLabel
                label="ACT"
                control={<Checkbox checked={checked[5]} onChange={handleChange7} />}
            />
            <FormControlLabel
                label="NT"
                control={<Checkbox checked={checked[6]} onChange={handleChange8} />}
            />
            <FormControlLabel
                label="TAS"
                control={<Checkbox disabled />} //checked={checked[7]} onChange={handleChange9} />} 
            />
        </Box>
    );

    // Show/Hide Filter
    let [showFilter, setShowFilter] = React.useState<boolean>(false)

    let filterCont = (
        <Card className={styles.filterCard}>
            <div>Filter by:</div>
            <div>
                <FormControlLabel 
                sx={{ display: 'flex', flexDirection: 'row'}}
                    label="All States"
                    control={
                        <Checkbox 
                            checked={checked[0] && checked[1] && checked[2] &&
                                checked[4] && checked[5] &&
                                checked[6]}
                            indeterminate={(!checked[0] || !checked[1] || !checked[2] ||
                                !checked[4] || !checked[5] ||
                                !checked[6])
                                &&
                                !(!checked[0] && !checked[1] && !checked[2] &&
                                    !checked[4] && !checked[5] &&
                                    !checked[6])}
                            onChange={handleChange1}
                        />
                    }
                />
                {children}
            </div>
        </Card>)

    // Filter Button Press
    const handleFilter = (event: React.SyntheticEvent) => {
        setShowFilter(!showFilter)
    };
    
    // Conditional Rendering
    let searchType
    if (type === "person") {
        searchType = "Search e.g. John Smith"
    } else if (type === "number") {
        searchType = "Search e.g. #1234/56"
    } else {
        searchType = "Search e.g. Some Company Pty. Ltd"
    }

    // HTML
    return (
        <div className={styles.root}>
            <div className={styles.search}>
                {/* Dropdown*/}
                <div className={styles.dropdownContainer}>
                    <FormControl fullWidth>
                        <InputLabel>Search Type</InputLabel>
                        <Select
                            value={type}
                            label="Search Type"
                            onChange={handleChange}
                        >
                            <MenuItem value="person">Auditor Name</MenuItem>
                            <MenuItem value="org">Organisation Name</MenuItem>
                            <MenuItem value="number">Case Number</MenuItem>
                        </Select>
                    </FormControl>
                </div>
                {/* Search Bar and Button */}
                <div className={styles.searchBarContainer}>
                    <Paper
                        sx={{ p: '10px 10px', display: 'flex', alignItems: 'center' }}
                    >
                        <InputBase
                            sx={{ ml: 1, flex: 1 }}
                            placeholder={searchType}
                            inputProps={{ 'aria-label': 'search' }}
                            onChange={handleSearch}
                            value={search}
                            onKeyUp={e => e.key === 'Enter' && handleSubmit(e)}
                        />
                        <Button variant="contained" onClick={handleSubmit}>{<SearchIcon />}</Button>
                    </Paper>
                </div>
                {/* Filter */}
                <div className={styles.filterContainer}>
                    <IconButton onClick={handleFilter} aria-label="filter" size="large" >
                        <FilterAltIcon fontSize="inherit" />
                    </IconButton>
                </div>
            </div>
            {showFilter ? filterCont : null}
            {/* Result Count */}
            <div className={styles.resultCountContainer}>
                { fetchSearchResults && (
                    <h4>{ totalResults !== null ? `${totalResults} result${totalResults !== 1 && 's'}` : 'Searching...'}</h4>
                )}
            </div>
            {/* Result Output */}
            <div className={styles.results}>
                { fetchSearchResults && (
                    <LazyList
                        fetch={fetchSearchResults}
                        listItem={(style, index, item?: CourtCase) => <CaseComponent courtCase={item} style={style} useExternalLink />}
                        itemSize={150} itemMargin={25}
                        minimumBatchSize={64} fetchMoreThreshold={10}
                    />
                )}
            </div>
        </div>
    )
}