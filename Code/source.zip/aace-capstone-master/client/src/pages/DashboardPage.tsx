import { CourtCase, DefaultService } from "@aace/capstone-common/codegen/client";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ReportProblemOutlinedIcon from '@mui/icons-material/ReportProblemOutlined';
import SensorsIcon from '@mui/icons-material/Sensors';
import Chip from '@mui/material/Chip';
import { useCallback, useState, useEffect } from "react";
import CaseComponent from '../components/CaseComponent';
import LazyList, { StaticItem } from "../components/LazyList";
import styles from './dashboard.module.css';

export default function DashboardPage() {
  const [totalPendingCases, setTotalPendingCases] = useState<number>(0);
  const [totalReviewedCases, setTotalReviewedCases] = useState<number>(0);
  
  const [lastSearchFetching, setLastSearchFetching] = useState<boolean>(true);
  const [lastSearchTime, setLastSearchTime] = useState<Date | null>(null);
  const [lastSearchSuccess, setLastSearchSuccess] = useState<boolean>(false);

  useEffect(function fetchHealth() {
    setLastSearchFetching(true);
    DefaultService.getHealth()
    .then((report) => {
      setLastSearchTime(new Date(report.lastAutoSearch.timestamp));
      setLastSearchSuccess(report.lastAutoSearch.completed);
    }).catch((err) => {
      setLastSearchTime(null);
      setLastSearchSuccess(false);
    }).finally(() => setLastSearchFetching(false));
  }, []);

  // Case feed
  const fetchFeed = useCallback((offset: number, limit: number) => {
    let response = DefaultService.getCaseFeed(limit, offset);
    response.then(r => {
      setTotalPendingCases(r.totalPending || 0);
      setTotalReviewedCases(r.totalReviewed || 0)
    }).catch(() => {});
    return response;
  }, []);

  const feedHeaders: StaticItem<CourtCase>[] = [
    {
      index: 0,
      item: (style: any, index: number) => <h2 style={style}>Pending cases</h2>,
      size: 32 
    },
    { 
      index: totalPendingCases,
      item: (style: any, index: number) => <h2 style={style}>Reviewed cases</h2>,
      size: 32, margin: 25 
    }
  ];

  return (
    <div className={styles.root}>

      <div className={styles.search}>
        <SensorsIcon color={ lastSearchTime !== null ? ( lastSearchSuccess ? 'success' : 'error' ) : 'disabled' } />
        <p>
          { lastSearchTime !== null ? 
          `Last search ${ lastSearchSuccess ? 'completed successfully' : 'failed'} ${ isToday(lastSearchTime) ? 'today' : 'on ' + lastSearchTime.toDateString()} at ${lastSearchTime.toLocaleTimeString()}` 
          : 
          ( lastSearchFetching ? 'Checking last search report...' : 'Last search status unknown' )
          }
        </p>
      </div>

      <div className={styles.results}>
        <div className={styles.pendAlert}>
          <Chip className="chip" icon={<ReportProblemOutlinedIcon />} label={`${totalPendingCases} pending cases`} 
            color={ totalPendingCases > 0 ? 'warning' : undefined } 
          />
        </div>
        <div className={styles.revAlert}>
          <Chip className="chip" icon={<InfoOutlinedIcon />} label={`${totalReviewedCases} reviewed cases`} variant="outlined" />
        </div>
      </div>

      <div className={styles.feedContainer}>
        <LazyList
          fetch={fetchFeed}
          listItem={(style, index, item?: CourtCase) => <CaseComponent courtCase={item} style={style} /> }
          itemSize={150} itemMargin={25} staticItems={feedHeaders}
        />
      </div>
    </div>
  )
}

function isToday(date: Date): boolean {
  let now = new Date();
  return date.getDate() === now.getDate() && date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
}