import { Auditor, CaseReview, CourtCase, DefaultService, UserAccount } from '@aace/capstone-common/codegen/client';
import { ArrowBack, FolderOpen, LocationOn, OpenInNew, PeopleAlt, Search, Visibility } from '@mui/icons-material';
import { IconButton, Paper } from '@mui/material';
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { useSnackbar } from "notistack";
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import styles from './casedetails.module.css';

// TODO: The header for this page overflows. It should wrap around to another line.
export default function CaseDetailsPage() {
    const location = useLocation();
    const navigate = useNavigate();
    const { enqueueSnackbar } = useSnackbar();

    const [loading, setLoading] = useState<boolean>(true);
    const [courtCase, setCourtCase] = useState<CourtCase | undefined>();
    const [reviews, setReviews] = useState<CaseReview[] | undefined>(undefined);
    const [auditors, setAuditors] = useState<Record<string, Auditor>>({});
    const [users, setUsers] = useState<Record<string, UserAccount>>({});

    useEffect(function fetchOnLoad() {
        fetchCase();
    }, [location]);
    
    function fetchCase() {
        setLoading(true);
        let search = new URLSearchParams(location.search);
        if (search.has('id')) {
            DefaultService.getCaseById(encodeURIComponent(search.get('id')!))
                .then((c) => {
                    setCourtCase(c);
                    setReviews(c.reviews);
                    if (c.taggedAuditors) {
                        for (let id in c.taggedAuditors) {
                            DefaultService.getAuditorById(id)
                                .then(auditor => {
                                    setAuditors((a) => ({ ...a, [id]: auditor }));
                                }).catch(err => console.error('Error fetching auditor details', err));
                        }
                    }
                    if (c.reviews) {
                        for (let r of c.reviews) {
                            DefaultService.getUserById(r.userId)
                            .then(user => {
                                setUsers(u => ({ ...u, [r.userId]: user }));
                            })
                            .catch(err => console.error('Error fetching UserAccount of reviewer', err));
                        }
                    }
                })
                .catch(err => {
                    console.error(err);
                    enqueueSnackbar('Failed to load case details. Refresh the page to retry.', { 'variant': 'error' })
                })
                .finally(() => setLoading(false));
        }
    }

    function reviewCase() {
        if (loading || !courtCase) return;
        setLoading(true);
        DefaultService.postCaseReview(encodeURIComponent(courtCase.locationState + '.' + courtCase.id))
            .then(() => { fetchCase(); enqueueSnackbar('Case marked as reviewed', { 'variant': 'success' }) })
            .catch(err => {
                console.error(err);
                enqueueSnackbar('Failed to mark case as reviewed', { 'variant': 'error' });
            })
            .finally(() => setLoading(false));
    }

    let parties: Record<string, string | null> = {};
    // Flip taggedAuditors around, from ID -> Name to Name -> ID
    if (courtCase) {
        for (let p of courtCase.parties) {
            parties[p] = null;
        }
        if (courtCase.taggedAuditors) {
            for (let auditorId in courtCase.taggedAuditors) {
                let partyName = courtCase.taggedAuditors[auditorId];
                if (auditors[auditorId]) {
                    let auditor = auditors[auditorId];
                    let name = auditor.id;
                    if (auditor.givenNames && auditor.lastName) {
                        name = `${auditor.givenNames} ${auditor.lastName}`;
                        if (auditor.organisation) {
                            name += ` (${auditor.organisation})`;
                        }
                    } else if (auditor.organisation) {
                        name = auditor.organisation;
                    }
                    parties[partyName] = name;
                } else {
                    parties[partyName] = auditorId;
                }
            }
        }
    }

    let isReviewed = reviews && reviews.length > 0;

    return (

        <div className={styles.containerFull}>
            <div className={styles.backArea}>
                <Link to="/"><IconButton><ArrowBack sx={{ fontSize: 50 }} /></IconButton></Link>
            </div>

            <div className={styles.containerBody}>

                <div className={styles.containerCaseDetails}>

                    <div className={styles.titleLine}>

                        <div className={styles.Icon}>
                            <FolderOpen sx={{ fontSize: 40 }} color="primary" />
                        </div>

                        <div className={styles.caseID}>
                            <strong>
                                {courtCase ? courtCase.id : '####'}
                            </strong>
                        </div>

                        <div className={styles.caseName}>
                            {courtCase ? courtCase.title || courtCase.friendlyName : ''}
                        </div>

                    </div>
                </div>

                <div className={styles.containerCaseDetails}>
                    <div className={styles.detailsLine}>

                        <div className={styles.detailItem}>
                            <div className={styles.detailIcon}>
                                <PeopleAlt sx={{ fontSize: 24 }} />
                            </div>

                            <div className={styles.detailText}>

                                <div className={styles.detailTitle}>
                                    Proceeding Category
                                </div>

                                <div className={styles.detailDesc}>
                                    {courtCase ? courtCase.proceedingsDetail : "Not specified"}
                                </div>

                            </div>
                        </div>

                        <div className={styles.detailItem}>
                            <div className={styles.detailIcon}>
                                <LocationOn sx={{ fontSize: 24 }} />
                            </div>

                            <div className={styles.detailText}>

                                <div className={styles.detailTitle}>
                                    State
                                </div>

                                <div className={styles.detailDesc}>
                                    {courtCase ? courtCase.locationState : ''}
                                </div>

                            </div>
                        </div>

                    </div>

                </div>

                <div className={styles.containerCaseDetails}>
                    <div className={styles.detailsLine}>

                        <div className={styles.detailItem}>
                            <div className={styles.detailIcon}>
                                <Search sx={{ fontSize: 24 }} />
                            </div>

                            <div className={styles.detailText}>

                                <div className={styles.detailTitle}>
                                    First Appeared
                                </div>

                                <div className={styles.detailDesc}>
                                    {courtCase ? new Date(courtCase.firstFound || '').toLocaleDateString() : ''}
                                </div>

                            </div>
                        </div>

                        {isReviewed && (
                            <div className={styles.detailItem}>
                                <div className={styles.detailIcon}>
                                    <Visibility sx={{ fontSize: 24 }} />
                                </div>

                                <div className={styles.detailText}>

                                    <div className={styles.detailTitle}>
                                        Reviewed by 
                                    </div>

                                    <div className={styles.detailDesc}>
                                        {users[reviews![0].userId]?.name || reviews![0].userId}
                                    </div>

                                </div>
                            </div>

                        )}

                    </div>

                </div>

                <div className={styles.containerCaseDetails}>
                    <div className={styles.containerTable}>
                        <TableContainer component={Paper}>
                            <Table sx={{ maxWidth: 500 }} aria-label="simple table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell align="left">Full Name</TableCell>
                                        <TableCell align="left">Auditor</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {Object.entries(parties).map(([partyName, auditorId], index) => (
                                        <TableRow
                                            key={index}
                                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        >
                                            <TableCell align="left">{partyName}</TableCell>
                                            <TableCell align="left">{auditorId || '-'}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>

                        </TableContainer>
                    </div>
                </div>


                <div className={styles.containerCaseDetails}>
                    <div className={styles.link}>
                        <div className={styles.detailIcon}>
                            Go to court website
                        </div>
                        <div className={styles.detailDesc}>
                            <a href={courtCase ? courtCase.url : ''}><IconButton><OpenInNew /></IconButton></a>
                        </div>
                    </div>
                </div>

                <div className={styles.containerCaseDetails}>

                    <div className={styles.buttonLine}>
                        <div className={styles.buttonItem}>
                            <Button variant="contained" onClick={reviewCase} disabled={isReviewed || loading}>
                                {!isReviewed ? 'Mark as reviewed' : 'Already reviewed'}
                            </Button>
                        </div>
                        <div className={styles.buttonItem}>
                            <Button variant="outlined" onClick={ev => navigate('/')}>
                                {!isReviewed ? 'Review later' : 'Close'}
                            </Button>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    )
}