import React, { useContext, useEffect, useState } from "react";
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import { Button, Paper, TextField } from "@mui/material";
import styles from './settings.module.css'
import { DefaultService } from "@aace/capstone-common/codegen/client";
import { useSnackbar } from "notistack";
import { UserContext } from "../App";

export default function SettingsPage() {
    const { enqueueSnackbar } = useSnackbar();
    const user = useContext(UserContext);

    const [autoSearchEnabled, setAutoSearchEnabled] = useState<boolean | undefined>();
    const [emailsEnabled, setEmailsEnabled] = useState<boolean | undefined>();

    const [ email, setEmail ] = useState<string>(user?.email || '');

    useEffect(function fetchSettings() {
        DefaultService.getSettingAutoSearch()
            .then(s => setAutoSearchEnabled(s.autoSearchEnabled))
            .catch(err => {
                console.error('Error fetching auto search setting', err);
                enqueueSnackbar('Failed to fetch automatic search setting', { variant: 'error' });
            });

        DefaultService.getSettingEmails()
            .then(s => setEmailsEnabled(s.notificationsEnabled))
            .catch(err => {
                console.error('Error fetching emails setting', err);
                enqueueSnackbar('Failed to fetch email notification setting', { variant: 'error' });
            });
    }, [autoSearchEnabled, emailsEnabled]);

    useEffect(function updateEmail() {
        if (user && user.email) {
            setEmail(user.email);
        }
    }, [ user ]);

    const handleAutoSearchChange = (on: boolean) => {
        DefaultService.setSettingAutoSearch({
            autoSearchEnabled: on
        })
        .then(s => setAutoSearchEnabled(on))
        .catch(err => {
            console.error('Error setting autosearch', err);
            enqueueSnackbar('Failed to update setting', { variant: 'error' });
        });
    }

    const handleEmailsChange = (on: boolean) => {
        DefaultService.setSettingEmails({
            notificationsEnabled: on
        })
        .then(s => setEmailsEnabled(on))
        .catch(err => {
            console.error('Error setting emails', err);
            enqueueSnackbar('Failed to update setting', { variant: 'error' });
        });
    }

    const handleUpdateEmail = () => {
        if (!user) return;
        DefaultService.postUser({
            id: user.id,
            email: email
        }).then(s => {
            user.email = email 
            setEmail(email);
            enqueueSnackbar('Updated profile email', { variant: 'success' });
        }).catch(err => {
            console.error('Error updating email', err);
            enqueueSnackbar('Failed to update email', { variant: 'error' });
        })
    }

    const handleRemoveEmail = () => {
        if (!user) return;
        DefaultService.postUser({
            id: user.id,
            email: ""
        }).then(s => {
            user.email = "";
            setEmail("");
            enqueueSnackbar('Removed profile email', { variant: 'success' });
        }).catch(err => {
            console.error('Error removing email', err);
            enqueueSnackbar('Failed to remove email', { variant: 'error' });
        })
    }

    return (
        <div>
            <Paper variant="outlined" className={styles.settingBox}>
                <h3>Automatic searches</h3>
                <div>
                    <p>
                        The server automatically runs searches in the background every day.
                        If you disable this feature, no new cases will be found. However, manual searches will continue to function.
                    </p>
                    <FormControlLabel
                        disabled={autoSearchEnabled === undefined}
                        control={<Switch checked={autoSearchEnabled !== undefined ? autoSearchEnabled : true} onChange={ev => handleAutoSearchChange(ev.target.checked)} />}
                        label="Run automatic searches"
                        labelPlacement="start"
                    />
                </div>
            </Paper>
            <Paper variant="outlined" className={styles.settingBox}>
                <h3>Email notifications</h3>
                <div>
                    <p>
                        When an automatic search finds one or more cases involving an auditor, all users with an email attached to their profile will receive a notification.
                        Emails are sent at most once per day, and will only be sent the first time a case appears in the search results.
                    </p>
                    <p>This setting controls the notifications for all users.</p>
                    <FormControlLabel
                        disabled={emailsEnabled === undefined}
                        control={<Switch checked={emailsEnabled !== undefined ? emailsEnabled : true} onChange={ev => handleEmailsChange(ev.target.checked)} />}
                        label="Send email notifications"
                        labelPlacement="start"
                    />
                    <h4 style={{ opacity: emailsEnabled ? '100%' : '70%'}}>Your profile</h4>
                    <p style={{ opacity: emailsEnabled ? '100%' : '70%'}}>To receive notifications, add your email address to your profile. To stop receiving them, remove it.</p>
                    <div className={styles.emailRow}>
                        <TextField style={{ width: '300px', flexShrink: 0, marginLeft: '16px' }} label='Email' 
                            variant='filled' disabled={!emailsEnabled} value={email} onChange={ev => setEmail(ev.target.value)}
                        />
                        <Button variant='contained' disabled={!emailsEnabled} onClick={handleUpdateEmail}>Update email</Button>
                        <Button variant='outlined' disabled={!emailsEnabled} onClick={handleRemoveEmail}>Remove email</Button>
                    </div>
                </div>
            </Paper>
        </div>
    )
}