import React from "react";
import { Link, useLocation } from "react-router-dom";
import SettingsIcon from '@mui/icons-material/Settings';
import styles from './NavBar.module.css';
import SearchIcon from '@mui/icons-material/Search';
import PeopleIcon from '@mui/icons-material/People';
import HomeIcon from '@mui/icons-material/Home';

export default function NavBar() {
    const location = useLocation();
    return (
        <div className={styles.root}>
            <div className={styles.boxes}>
                <p>LOGO</p>
            </div>

            <Link className={styles.boxes} to="/">
                <HomeIcon style={{ color: location.pathname === "/" ? "#1976d2" : "black" }} fontSize='large' />
                <p>Dashboard</p>
            </Link>

            <Link className={styles.boxes} to="/auditors">
                <PeopleIcon style={{ color: location.pathname === "/auditors" ? "#1976d2" : "black" }} fontSize='large' />
                <p>Auditors</p>
            </Link>

            <Link className={styles.boxes} to="/search">
                <SearchIcon style={{ color: location.pathname === "/search" ? "#1976d2" : "black" }} fontSize='large' />
                <p>Search</p>
            </Link>

            <Link className={styles.boxes} to="/settings">
                <SettingsIcon style={{ color: location.pathname === "/settings" ? "#1976d2" : "black" }} fontSize='large' />
                <p>Settings</p>
            </Link>
        </div>
    )
}