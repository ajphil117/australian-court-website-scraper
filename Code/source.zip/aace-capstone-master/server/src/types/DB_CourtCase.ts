import { CourtCase } from "@aace/capstone-common/codegen/client";

export type DB_CourtCase = Omit<CourtCase, 'firstFound'> & { firstFound: Date };

/**
 * Converts a regular CourtCase object (as defined in the OpenAPI spec) into a DB_CourtCase object,
 * which represents how CourtCases are stored in the database. 
 * 
 * The only difference is date fields
 * are ISO strings in the regular objects, but Date() objects in the database.
 * @param courtCase CourtCase object to convert
 * @returns A DB_CourtCase object, ready to be inserted into the database.
 */
export function courtCaseToDB(courtCase: CourtCase): DB_CourtCase {
    let obj = courtCase as any;
    if (courtCase.firstFound) {
        obj.firstFound = new Date(courtCase.firstFound);
    }
    return obj as DB_CourtCase;
}

export function courtCaseFromDB(dbCourtCase: DB_CourtCase): CourtCase {
    let { _id, ...obj } = dbCourtCase as any;
    if (dbCourtCase.firstFound) {
        obj.firstFound = dbCourtCase.firstFound.toISOString();
    }
    return obj as CourtCase;
}