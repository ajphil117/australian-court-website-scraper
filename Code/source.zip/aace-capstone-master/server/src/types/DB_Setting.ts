import { Binary } from "mongodb";

export type DB_Setting = {
    key: string;
};

export const SETTING_PASSWORD = 'GroupPassword';
export type SettingPassword = DB_Setting & {
    hash: Binary;
    salt: Binary;
}

export const SETTING_AUTOSEARCH = 'AutoSearch';
export type SettingAutoSearch = DB_Setting & {
    autoSearchEnabled: boolean
}
export const SettingAutoSearchDefault: SettingAutoSearch = {
    key: SETTING_AUTOSEARCH,
    autoSearchEnabled: true
}

export const SETTING_EMAILS = 'Emails';
export type SettingEmails = DB_Setting & {
    notificationsEnabled: boolean
}
export const SettingEmailsDefault: SettingEmails = {
    key: SETTING_EMAILS,
    notificationsEnabled: true
}