import { HealthReport } from "@aace/capstone-common/codegen/client";

type ChangeFields<T, R> = Omit<T, keyof R> & R;
/**
 * See DB_CourtCase.
 */
export type DB_HealthReport = ChangeFields<HealthReport, {
    lastAutoSearch: Omit<HealthReport['lastAutoSearch'], 'timestamp'>
} & { lastAutoSearch: { timestamp: Date } }>;

export function reportToDB(report: HealthReport): DB_HealthReport {
    let obj = report as any;
    obj.lastAutoSearch.timestamp = new Date(report.lastAutoSearch.timestamp);
    return obj as DB_HealthReport;
}

export function reportFromDB(dbReport: DB_HealthReport): HealthReport {
    let { _id, ...obj } = dbReport as any;
    obj.lastAutoSearch.timestamp = dbReport.lastAutoSearch.timestamp.toISOString();
    return obj as HealthReport;
}