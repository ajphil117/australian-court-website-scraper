export type DB_MailLog = {
    timestamp: Date,
    newestCase: Date,
    completed: boolean,
    error?: string
}