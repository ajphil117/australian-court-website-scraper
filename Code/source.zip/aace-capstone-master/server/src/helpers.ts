export function filteredProperties(obj: any, allowedKeys: string[]): any {
    let f: any = {};
    for (let allowed of allowedKeys) {
        if (obj[allowed] != undefined) {
            let val = obj[allowed];
            if (typeof val === 'string') {
                val = val.trim();
            }
            f[allowed] = val;
        }
    }
    return f;
}