import { CourtCase, PagedResponse } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { AllScrapers } from "../..";
import Scraper, { ScraperSearchField, ScraperSearchQuery } from "../../scrape/Scraper";

export const GET: Operation = [
    async (req, res, next) => {
        let sQuery: ScraperSearchQuery = {
            text: req.query.query! as string, textField: req.query.type as ScraperSearchField,
        };
        if (req.query.fromDate) {
            let fromDate = new Date(req.query.fromDate as string);
            if (!isNaN(fromDate.valueOf())) sQuery.fromDate = fromDate;
        }

        let includedScrapers: Scraper[] = [];
        if (req.query.states) {
            let states = (req.query.states as string);
            for (let s of states) {
                if (AllScrapers[s]) includedScrapers.push(AllScrapers[s].scraper);
            }
        } else {
            includedScrapers = Object.values(AllScrapers).map(s => s.scraper);
        }

        let cases: CourtCase[] = [];
        let limit = req.query.limit ? parseInt(req.query.limit as string) : 25;
        let offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
        let total = 0;

        let tmpOffset = offset;
        for (let scraper of includedScrapers) {
            // Run a scrape. We might discard these results, we just need to see what the total is first.
            sQuery.offset = tmpOffset;
            sQuery.limit = limit - cases.length;
            let sResult: Awaited<ReturnType<Scraper>>;
            try {
                sResult = await scraper(sQuery);
            } catch (ex) {
                continue; 
            }
            total += sResult.total;
            if (sQuery.limit === 0) continue; // No more items can fit on this page, but we still need to hit all scrapers to get the total item count 
            // Check if the user-requested offset is before or after this scraper's total
            if (tmpOffset < sResult.total) {
                cases.push(...sResult.results);
                tmpOffset -= sResult.offset + sResult.results.length;
            } else {
                tmpOffset -= sResult.total;
            }
            if (tmpOffset < 0) tmpOffset = 0;
        }

        let page: PagedResponse = {
            count: cases.length,
            offset: offset, limit: limit,
            total: total
        };
        
        res.status(200).json({
            ...page,
            items: cases 
        });
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/search.json').get; 