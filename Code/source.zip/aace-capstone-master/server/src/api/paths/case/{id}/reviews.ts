import { CaseReview, UserAccount } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { db, DB_COLLECTION_REVIEWS } from "../../../..";

export const POST: Operation = [
    async (req, res, next) => {
        // Try parse the case locationState and ID from the request path
        let id = req.params.id.split('.', 2);
        if (id.length != 2) {
            res.status(400).json({
                status: 400,
                errors: [
                    { 
                        path: "id",
                        errorCode: "invalidCaseStateIDCombo",
                        message: "the case ID must be a location state and a court database ID separated by a period",
                        location: "path"
                    }
                ]
            });
            return;
        }
        id[1] = decodeURIComponent(id[1]);

        try {
            const reviews = db().collection<CaseReview>(DB_COLLECTION_REVIEWS);

            await reviews.insertOne({
                caseId: id[0] + "." + id[1], userId: ((req as any).user as UserAccount).id,
                timestamp: new Date() as any
            });

            res.status(200).send();
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
]

POST.apiDoc = require('@aace/capstone-common/api-docs/paths/case/{id}/reviews.json').post;