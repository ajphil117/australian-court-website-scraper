import { CaseReview, CourtCase } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Filter, FindOptions } from "mongodb";
import { db, DB_COLLECTION_CASES, DB_COLLECTION_REVIEWS } from "../../..";
import { courtCaseFromDB, DB_CourtCase } from "../../../types/DB_CourtCase";

export const GET: Operation = [
    async (req, res, next) => {
        // Try parse the case locationState and ID from the request path
        let id = req.params.id.split('.', 2);
        if (id.length != 2) {
            res.status(400).json({
                status: 400,
                errors: [
                    { 
                        path: "id",
                        errorCode: "invalidCaseStateIDCombo",
                        message: "the case ID must be a location state and a court database ID separated by a period",
                        location: "path"
                    }
                ]
            });
            return;
        }
        id[1] = decodeURIComponent(id[1]);

        try {
            const cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
            const query: Filter<DB_CourtCase> = { locationState: id[0] as any, id: id[1] }; 
            
            let courtCase = await cases.findOne(query);
            
            if (courtCase != null) {
                // Grab the reviews for this case, too
                const reviews = db().collection<CaseReview>(DB_COLLECTION_REVIEWS);
                
                let caseReviews = await reviews.find({ caseId: id[0] + "." + id[1] }, { limit: 500 }).toArray();

                res.status(200).json({
                    ...courtCaseFromDB(courtCase),
                    reviews: caseReviews.map(r => { let {_id, ...o} = r; return o;} )
                });
            } else {
                res.status(404).json({ message: "No case was found with that state/ID." });
            }

        } catch (err) {
            res.status(503);
            next(err);
        }
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/case/{id}.json').get; 