import { Operation } from "express-openapi";
import { Filter, FindOptions } from "mongodb";
import { db, DB_COLLECTION_USERS, } from "../..";
import { PagedResponse, UserAccount } from "@aace/capstone-common/codegen/client";
import { filteredProperties } from "../../helpers";
const crypto: Crypto = require('crypto');

export const GET: Operation = [
    async (req, res, next) => {
        let skip = req.query.offset != undefined ? parseInt(req.query.offset as string) : 0;
        let limit = req.query.limit != undefined ? parseInt(req.query.limit as string) : 10;

        try {
            const users = db().collection<UserAccount>(DB_COLLECTION_USERS);
            let filter: Filter<UserAccount> = {};
            const options: FindOptions<UserAccount> = {
                sort: { name: 1 }, skip: skip, limit: limit
            };

            if (req.query.query) {
                filter = { name: { $regex: req.query.query as string, $options: 'i' } };
            }
            
            let results = await users.find(filter, options).toArray();

            let page: PagedResponse = {
                offset: skip, limit: limit,
                count: results.length, total: await users.countDocuments(filter) 
            }

            res.status(200).json({
                ...page,
                items: results.map(u => { let {_id, ...user} = u; return user; } )
            });
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

const doc = require('@aace/capstone-common/api-docs/paths/users.json');
GET.apiDoc = doc.get; 

const userAllowedFields = [
    "name", "email", "colourA", "colourB"
];

export const POST: Operation = [
    async (req, res, next) => {
        try {
            const users = db().collection<UserAccount>(DB_COLLECTION_USERS);
            if (req.body.id != undefined) {
                // This is an update operation
                let query: Filter<UserAccount> = { id: req.body.id };
                let uResult = await users.findOneAndUpdate(query, {
                   "$set": filteredProperties(req.body, userAllowedFields) 
                }, { returnDocument: 'after' });
                
                if (uResult.value !== null) {
                    let { _id,...user } = uResult.value;
                    res.status(200).json(user);
                } else {
                    res.status(404).send();
                }
            } else {
                // This is a create operation
                let newUser = filteredProperties(req.body, userAllowedFields);
                if (!newUser.name) {
                    res.status(400).json({
                        status: 400,
                        errors: [
                            {
                                location: "body",
                                errorCode: "user.no-name",
                                message: "new user account must include at least a display name"
                            }
                        ]
                    });
                    return;
                } 
                
                newUser.id = crypto.randomUUID();
                await users.insertOne(newUser);
                let { _id,...user } = newUser;
                res.status(201).json(user);
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

POST.apiDoc = doc.post; 

export const DELETE: Operation = [
    async (req, res, next) => {
        try {
            const users = db().collection<UserAccount>(DB_COLLECTION_USERS);
            let query: Filter<UserAccount> = { id: req.body.id };
            await users.deleteOne(query);

            res.status(204).send();
        } catch (err) {
            res.status(503);
            next(err);
        }
    }

];

DELETE.apiDoc = doc.delete;