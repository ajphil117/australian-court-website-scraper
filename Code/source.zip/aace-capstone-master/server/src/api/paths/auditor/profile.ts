import { Auditor } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Filter, FindOptions } from "mongodb";
import { db, DB_COLLECTION_AUDITORS, } from "../../..";
import { filteredProperties } from "../../../helpers";
const crypto: Crypto = require('crypto');

export const GET: Operation = [
    async (req, res, next) => {
        try {
            const auditors = db().collection<Auditor>(DB_COLLECTION_AUDITORS);
            const query: Filter<Auditor> = { id: req.query.id };
            const options: FindOptions<Auditor> = {
                sort: { lastName: 1, givenNames: 1 },
            };
            
            let result = await auditors.find(query, options).toArray();

            if (result.length > 0) {
                let { _id,...auditor } = result[0];
                res.status(200).json(auditor);
            } else {
                res.status(404).json({ message: "No auditor was found with that ID." });
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

const doc = require('@aace/capstone-common/api-docs/paths/auditor/profile.json');
GET.apiDoc = doc.get; 

const auditorAllowedFields = [
    "givenNames", "lastName", "organisation",
    "approvedInStates"
];

export const POST: Operation = [
    async (req, res, next) => {
        try {
            const auditors = db().collection<Auditor>(DB_COLLECTION_AUDITORS);
            if (req.body.id != undefined) {
                // This is an update operation
                let query: Filter<Auditor> = { id: req.body.id };
                let uResult = await auditors.findOneAndUpdate(query, {
                   "$set": filteredProperties(req.body, auditorAllowedFields) 
                }, { returnDocument: 'after' });
                
                if (uResult.value !== null) {
                    let { _id,...auditor } = uResult.value;
                    res.status(200).json(auditor);
                } else {
                    res.status(404).send();
                }
            } else {
                // This is a create operation
                let newAuditor = filteredProperties(req.body, auditorAllowedFields);
                if (!newAuditor.organisation && !(newAuditor.lastName && newAuditor.givenNames)) {
                    res.status(400).json({
                        status: 400,
                        errors: [
                            {
                                location: "body",
                                errorCode: "auditor.no-name",
                                message: "auditor profile must include either 'organisation' or 'lastName' and 'givenNames'"
                            }
                        ]
                    });
                    return;
                } 
                
                newAuditor.id = crypto.randomUUID();
                newAuditor.created = new Date();
                try {
                    await auditors.insertOne(newAuditor);
                } catch (err) {
                    res.status(400).json({
                        status: 400,
                        errors: [ 
                            {
                                location: "body",
                                errorCode: "db.schema-rejected",
                                message: "the database refused to insert the provided object, ensure it is of the correct schema"
                            }
                        ] 
                    });
                    return;
                }
                let { _id,...auditor } = newAuditor;
                res.status(201).json(auditor);
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

POST.apiDoc = doc.post; 

export const DELETE: Operation = [
    async (req, res, next) => {
        try {
            const auditors = db().collection<Auditor>(DB_COLLECTION_AUDITORS);
            let query: Filter<Auditor> = { id: req.body.id };
            await auditors.deleteOne(query);

            res.status(204).send();
        } catch (err) {
            res.status(503);
            next(err);
        }
    }

];

DELETE.apiDoc = doc.delete;