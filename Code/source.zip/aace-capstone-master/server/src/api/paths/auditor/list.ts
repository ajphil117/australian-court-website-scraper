import { Auditor, PagedResponse } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Filter, FindOptions } from "mongodb";
import { db, DB_COLLECTION_AUDITORS } from "../../..";

export const GET: Operation = [
    async (req, res, next) => {
        let skip = req.query.offset != undefined ? parseInt(req.query.offset as string) : 0;
        let limit = req.query.limit != undefined ? parseInt(req.query.limit as string) : 10;

        try {
            const auditors = db().collection<Auditor>(DB_COLLECTION_AUDITORS);
            let filter: Filter<Auditor> = {};
            const options: FindOptions<Auditor> = {
                sort: { lastName: 1, firstName: 1, organisation: 1 }, skip: skip, limit: limit
            };

            if (req.query.query) {
                let regex = { $regex: req.query.query as string, $options: 'i' };
                filter = { $or: [
                    { givenNames: regex }, { lastName: regex }, { organisation: regex }
                ]};
            }
            
            let results = await auditors.find(filter, options).toArray();
            let page: PagedResponse = {
                offset: skip, limit: limit,
                count: results.length, total: await auditors.countDocuments(filter) 
            }

            res.status(200).json({
                ...page,
                items: results.map(c => { let {_id, ...auditor} = c; return auditor; })
            });

        } catch (err) {
            res.status(503);
            next(err);
        }
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/auditor/list.json').get; 