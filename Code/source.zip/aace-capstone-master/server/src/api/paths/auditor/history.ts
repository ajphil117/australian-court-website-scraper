import { PagedResponse } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Document, Filter } from "mongodb";
import { db, DB_COLLECTION_CASES } from "../../..";
import { courtCaseFromDB, DB_CourtCase } from "../../../types/DB_CourtCase";

export const GET: Operation = [
    async (req, res, next) => {
        let skip = req.query.offset != undefined ? parseInt(req.query.offset as string) : 0;
        let limit = req.query.limit != undefined ? parseInt(req.query.limit as string) : 10;

        try {
            const cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
            const query: Filter<DB_CourtCase> = { [`taggedAuditors.${req.query.id}`]: { $exists: true } };

            const pipeline: Document[] = [
                { $addFields: { "localId": { $concat: [ "$locationState", ".", "$id" ] } } },
                { $lookup: {
                    from: "case_reviews",
                    localField: "localId",
                    foreignField: "caseId",
                    as: "reviews"
                }},
                { $match: query },
                { $facet: {
                    "totalCount": [{ $count: 'total' }],
                    "cases": [
                        { $sort: { firstFound: -1 } },
                        { $skip: skip },
                        { $limit: limit },
                        { $project: { localId: 0 }}
                    ]
                }}
            ];
            
            let results = (await cases.aggregate(pipeline).toArray())[0];
            let page: PagedResponse = {
                offset: skip, limit: limit,
                count: results.cases.length, total: results.totalCount[0]?.total | 0
            }

            res.status(200).json({
                ...page,
                items: results.cases.map((c: any) => courtCaseFromDB(c))
            });
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

const doc = require('@aace/capstone-common/api-docs/paths/auditor/history.json');
GET.apiDoc = doc.get; 
