import { UserAccount } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Filter } from "mongodb";
import { db, DB_COLLECTION_USERS } from "../..";

export const GET: Operation = [
    async (req, res, next) => {
        try {
            const auditors = db().collection<UserAccount>(DB_COLLECTION_USERS);
            const query: Filter<UserAccount> = { id: req.query.id };
            
            let result = await auditors.find(query, {}).toArray();

            if (result.length > 0) {
                let { _id,...user } = result[0];
                res.status(200).json(user);
            } else {
                res.status(404).json({ message: "No user was found with that ID." });
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/user.json').get;