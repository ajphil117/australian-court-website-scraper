import { Operation } from "express-openapi";
import { db, DB_COLLECTION_HEALTH } from "../..";
import { DB_HealthReport, reportFromDB } from "../../types/DB_HealthReport";

export const GET: Operation = [
    async (req, res, next) => {
        try {
            const health = db().collection<DB_HealthReport>(DB_COLLECTION_HEALTH);
            
            let result = await health.findOne({}, { sort: { $natural: -1 }});

            if (result !== null) { 
                res.status(200).json(reportFromDB(result));
            } else {
                res.status(204).send();
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/health.json').get;