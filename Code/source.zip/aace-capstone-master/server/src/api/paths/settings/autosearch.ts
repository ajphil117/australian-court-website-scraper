import { Operation } from "express-openapi";
import { Filter, UpdateFilter } from "mongodb";
import { AllScrapers, AutoSearchHours, db, DB_COLLECTION_SETTINGS } from "../../..";
import { disableAutoSearch, enableAutoSearch, isAutoSearchEnabled } from "../../../AutoSearch";
import { SettingAutoSearch, DB_Setting, SETTING_AUTOSEARCH, SettingAutoSearchDefault } from "../../../types/DB_Setting";

export async function getSettingAutoSearch(): Promise<SettingAutoSearch> {
    const settings = db().collection<SettingAutoSearch>(DB_COLLECTION_SETTINGS);
    let filter: Filter<SettingAutoSearch> = { key: SETTING_AUTOSEARCH };
    let result = await settings.findOne(filter);
    if (result === null) {
        return SettingAutoSearchDefault;
    } else {
        let {_id, ...s} = result;
        return s;
    }
}

export const GET: Operation = [
    async (req, res, next) => {
        try {
            let s = await getSettingAutoSearch();
            res.status(200).json(s);
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/settings/autosearch.json').get;

export const PUT: Operation = [
    async (req, res, next) => {
        if (req.body.autoSearchEnabled) {
            if (!isAutoSearchEnabled()) {
                enableAutoSearch(AutoSearchHours, Object.values(AllScrapers));
            }
        } else {
            disableAutoSearch();
        }

        try {
            const settings = db().collection<DB_Setting>(DB_COLLECTION_SETTINGS);
            let filter: Filter<DB_Setting> = { key: SETTING_AUTOSEARCH };
            let update: UpdateFilter<SettingAutoSearch> = {
                $setOnInsert: {
                    key: SETTING_AUTOSEARCH
                },
                $set: {
                    autoSearchEnabled: req.body.autoSearchEnabled
                }
            };
            let result = await settings.updateOne(filter, update, { upsert: true });

            if (result.acknowledged) {
                res.status(200).send();
            } else {
                throw Error("Change not acknowledged");
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

PUT.apiDoc = require('@aace/capstone-common/api-docs/paths/settings/autosearch.json').put;