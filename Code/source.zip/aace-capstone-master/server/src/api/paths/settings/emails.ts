import { Operation } from "express-openapi";
import { Filter, UpdateFilter } from "mongodb";
import { db, DB_COLLECTION_SETTINGS, MailerConfiguration } from "../../..";
import { closeMailer, initMailer, isMailerInit } from "../../../Mailer";
import { DB_Setting, SettingEmails, SettingEmailsDefault, SETTING_EMAILS } from "../../../types/DB_Setting";

export async function getSettingEmails(): Promise<SettingEmails> {
    const settings = db().collection<SettingEmails>(DB_COLLECTION_SETTINGS);
    let filter: Filter<SettingEmails> = { key: SETTING_EMAILS };
    let result = await settings.findOne(filter);
    if (result === null) {
        return SettingEmailsDefault;
    } else {
        let {_id, ...s} = result;
        return s;
    }
}

export const GET: Operation = [
    async (req, res, next) => {
        try {
            let s = await getSettingEmails();
            res.status(200).json(s);
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/settings/emails.json').get;

export const PUT: Operation = [
    async (req, res, next) => {
        if (req.body.notificationsEnabled) {
            if (!isMailerInit() && MailerConfiguration) {
                initMailer(MailerConfiguration);
            }
        } else {
            closeMailer();
        }

        try {
            const settings = db().collection<DB_Setting>(DB_COLLECTION_SETTINGS);
            let filter: Filter<DB_Setting> = { key: SETTING_EMAILS };
            let update: UpdateFilter<SettingEmails> = {
                $setOnInsert: {
                    key: SETTING_EMAILS
                },
                $set: {
                    notificationsEnabled: req.body.notificationsEnabled
                }
            };
            let result = await settings.updateOne(filter, update, { upsert: true });

            if (result.acknowledged) {
                res.status(200).send();
            } else {
                throw Error("Change not acknowledged");
            }
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
];

PUT.apiDoc = require('@aace/capstone-common/api-docs/paths/settings/emails.json').put;