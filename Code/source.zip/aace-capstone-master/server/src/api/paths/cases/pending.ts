import { PagedResponse } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { AggregateOptions, Document, Filter, FindOptions } from "mongodb";
import { db, DB_COLLECTION_CASES } from "../../..";
import { courtCaseFromDB, DB_CourtCase } from "../../../types/DB_CourtCase";

export const GET: Operation = [
    async (req, res, next) => {
        // OpenAPI middleware has already validated our params
        let skip = req.query.offset != undefined ? parseInt(req.query.offset as string) : 0;
        let limit = req.query.limit != undefined ? parseInt(req.query.limit as string) : 10;

        try {
            const cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
            const pipeline: Document[] = [
                { $addFields: { "localId": { $concat: [ "$locationState", ".", "$id" ] } } },
                { $lookup: {
                    from: "case_reviews",
                    localField: "localId",
                    foreignField: "caseId",
                    as: "reviews"
                }},
                { $match: { 'reviews.0': { $exists: false } } },
                { $facet: {
                    "totalCount": [{ $count: 'total' }],
                    "pendingCases": [
                        { $sort: { firstFound: -1 } },
                        { $skip: skip },
                        { $limit: limit },
                        { $project: { localId: 0, reviews: 0 }}
                    ]
                }}
            ];
            
            let results = (await cases.aggregate(pipeline).toArray())[0];
            let page: PagedResponse = {
                offset: skip, limit: limit,
                count: results.pendingCases.length, total: results.totalCount[0]?.total || 0
            }

            res.status(200).json({
                ...page,
                items: results.pendingCases.map((c: any) => courtCaseFromDB(c))
            });
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/cases/pending.json').get; 