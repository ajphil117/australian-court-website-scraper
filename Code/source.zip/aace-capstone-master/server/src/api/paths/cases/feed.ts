import { PagedResponse } from "@aace/capstone-common/codegen/client";
import { Operation } from "express-openapi";
import { Document } from "mongodb";
import { db, DB_COLLECTION_CASES } from "../../..";
import { courtCaseFromDB, DB_CourtCase } from "../../../types/DB_CourtCase";

export const GET: Operation = [
    async (req, res, next) => {
        let skip = req.query.offset != undefined ? parseInt(req.query.offset as string) : 0;
        let limit = req.query.limit != undefined ? parseInt(req.query.limit as string) : 10;

        try {
            const cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
            const pipeline: Document[] = [
                { $addFields: { "localId": { $concat: [ "$locationState", ".", "$id" ] } } },
                { $lookup: {
                    from: "case_reviews",
                    localField: "localId",
                    foreignField: "caseId",
                    as: "reviews"
                }},
                { $addFields: { "isReviewed": { $gt: [ { $size: "$reviews" }, 0] } } },
                { $facet: {
                    "totalCount": [{ $count: 'total' }],
                    "cases": [
                        { $sort: { isReviewed: 1, firstFound: -1 } },
                        { $skip: skip },
                        { $limit: limit },
                        { $project: { localId: 0, reviews: 0, isReviewed: 0 }}
                    ],
                    "pendingCount": [
                        { $match: { isReviewed: false }},
                        { $count: 'total' }
                    ],
                }}
            ];
            
            let results = (await cases.aggregate(pipeline).toArray())[0];
            let total = results.totalCount[0]?.total || 0;
            let page: PagedResponse = {
                offset: skip, limit: limit,
                count: results.cases.length, total: total
            }

            let totalPending = results.pendingCount[0]?.total || 0;
            let totalReviewed = total - totalPending;
            res.status(200).json({
                ...page,
                totalPending: totalPending, totalReviewed: totalReviewed,
                items: results.cases.map((c: any) => courtCaseFromDB(c))
            });
        } catch (err) {
            res.status(503);
            next(err);
        }
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/cases/feed.json').get; 