import { Operation } from "express-openapi";

export const GET: Operation = [
    (req, res, next) => {
        res.status(200).send(sayHello(req.query.name! as string));
    }
]

GET.apiDoc = require('@aace/capstone-common/api-docs/paths/hello.json').get;

export function sayHello(name: string): string { return `Hello there, ${name}!`; }