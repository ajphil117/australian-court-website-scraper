import { CourtCase } from "@aace/capstone-common/codegen/client";
import Scraper, { ScraperSearchField, ScraperSearchQuery } from "./Scraper";
import csv from 'csv-parser';
import fetch from "node-fetch"
import { baseStr, nameMatch } from "../AutoSearch";

const searchNT: Scraper = async function (searchQuery: ScraperSearchQuery) {
    const headers = ["case_type", "location", "court_room", "people_involved", "role", "case_number", "exhibit", "date", "time", "listed_for", "offences"]

    let fileCont: any[] = [];
    let filteredCont: any[] = [];
    let returnedCases: CourtCase[] = [];

    const res = await fetch('https://localcourt.nt.gov.au/dailycourts/CriminalCourt.csv', {
        method: 'GET',
    })

    if (res.ok == false) {
        throw Error(`Bad status response while fetching search page: ${res.status} - ${res.statusText}`)
    }

    if (!res.body) throw Error('Response has no body');

    let readPipe = res.body
        .pipe(csv({ separator: ';', headers }))
        .on('data', (data: any) => fileCont.push(data))
    let readingDone = new Promise(function (resolve, reject) {
        readPipe.on('end', resolve)
        readPipe.on('error', reject)
    })

    await readingDone

    // Remove first header line
    fileCont.shift()
    fileCont.shift()

    // Separate important info 
    for (var content in fileCont) {
        delete fileCont[content]["location"]
        delete fileCont[content]["court_room"]
        delete fileCont[content]["role"]
        delete fileCont[content]["exhibit"]
        delete fileCont[content]["listed_for"]
        delete fileCont[content]["offences"]

        fileCont[content]["case_type"] = fileCont[content]["case_type"].trim()
        fileCont[content]["people_involved"] = fileCont[content]["people_involved"].trim()
        fileCont[content]["case_number"] = fileCont[content]["case_number"].trim()
        fileCont[content]["date"] = fileCont[content]["date"].trim()
        fileCont[content]["time"] = fileCont[content]["time"].trim()
    }

    // Delete duplicates and combine details
    filteredCont = deleteDuplicate(fileCont)
    filteredCont = combineCases(filteredCont)

    // Search
    let results: { [key: string]: string }[] = [];

    if (searchQuery.textField == "number") {
        for (var caseCont in filteredCont) {
            if (filteredCont[caseCont]["case_number"].includes(searchQuery.text)) {
                results.push(filteredCont[caseCont])
            }
        }
    } else if (searchQuery.textField == "person") {
        for (var caseCont in filteredCont) {
            if (baseStr(filteredCont[caseCont]["people_involved"]).includes(baseStr(searchQuery.text))) {
                results.push(filteredCont[caseCont])
            }
        }
    } else if (searchQuery.textField == "org") {
        // needs to be edited when know who is in what company
        for (var caseCont in filteredCont) {
            if (baseStr(filteredCont[caseCont]["people_involved"]).includes(baseStr(searchQuery.text))) {
                results.push(filteredCont[caseCont])
            }
        }
    }

    // Convert results into case compnents
    let caseNumber = ""
    let url = "https://localcourt.nt.gov.au/dailycourts/CriminalCourt.csv"
    let parties: string[] = []
    let date = ""

    for (var returnedCase in results) {
        caseNumber = results[returnedCase]["case_number"]
        url = url
        parties = results[returnedCase]["people_involved"].split(",")
        date = results[returnedCase]["date"]

        // Reorder names of parties
        let reorderedParties: string[] = []

        // for each person in parties array
        for (var i = 0; i < parties.length; i++) {
            let person = parties[i]
            let names: string[] = []
            names = person.split(" ");
            let lastNames = []

            // for each of that persons names, identify last names
            for (var j = 0; j < names.length; j++) {
                let name = names[j]

                if (name.toUpperCase() == name && name.length > 1) {
                    lastNames.push(name)
                }
            }

            // for each of that persons names, remove last names
            for (var a = 0; a < lastNames.length; a++) {
                for (var b = 0; b < names.length; b++) {
                    if (lastNames[a] == names[b]) {
                        names.splice(b, 1)
                    }
                }
            }

            // add last names to end of array
            for (var m = 0; m < lastNames.length; m++) {
                let lastName = lastNames[m].charAt(0).toUpperCase() + lastNames[m].slice(1).toLowerCase()
                names.push(lastName)
            }

            // add to reordered array
            reorderedParties.push(names.toString().replace(/,/g, " "))
        }

        returnedCases.push({
            id: caseNumber,
            locationState: 'NT',
            url: url,
            parties: reorderedParties,
            // firstFound: date
        })
    }

    // Pagination
    let qOffset = searchQuery.offset || 0;
    let qLimit = searchQuery.limit || 10;

    return {
        results: returnedCases.slice(qOffset, qOffset + qLimit),
        offset: qOffset,
        limit: qLimit,
        total: returnedCases.length
    }
};
export default searchNT;

function deleteDuplicate(list: any[]) {
    for (let i = list.length - 1; i > 0; i--) {
        for (let j = i - 1; j >= 0; j--) {
            if (list[j]["case_type"] == list[i]["case_type"] &&
                list[j]["people_involved"] == list[i]["people_involved"] &&
                list[j]["case_number"] == list[i]["case_number"] &&
                list[j]["date"] == list[i]["date"] &&
                list[j]["time"] == list[i]["time"]) {
                list.splice(i, 1)
                break
            }
        }
    }

    return list;
}

function combineCases(list: any[]) {
    for (let i = list.length - 1; i > 0; i--) {
        for (let j = i - 1; j >= 0; j--) {
            if (list[j]["case_number"] == list[i]["case_number"]) {                
                list[j]["people_involved"] = list[j]["people_involved"] + "," + (list[i]["people_involved"])                
                list.splice(i, 1)
                break
            }
        }
    }

    return list;
}