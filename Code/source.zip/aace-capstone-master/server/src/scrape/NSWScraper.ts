import fetch from "node-fetch";
import { CourtCase } from "@aace/capstone-common/codegen/client";
import Scraper, { ScraperSearchField, ScraperSearchQuery } from "./Scraper" ;

const searchNSW: Scraper = async function (query: ScraperSearchQuery) {

    // setting default - can remove if there is an overaching default 
    if (typeof query.offset == 'undefined') {
        query.offset = 0
    }

    if (typeof query.limit == 'undefined') {
        query.limit = 30
    }

    //Variables that will be set once response is recieved 
    let offset = query.offset;
    let count = query.limit;
    let totalHits = 0;

    let results: CourtCase[] = [];

    //Searches all available dates. NSW's online court registery only has cases 3 weeks in the future and 1 week in the past available. 
    let today = new Date();
    let dd1 = String(today.getDate()).padStart(2, '0');
    let mm1 = String(today.getMonth() - 2).padStart(2, '0'); //January is 0!
    let yyyy1 = today.getFullYear();

    let dd2 = String(today.getDate()).padStart(2, '0');
    let mm2 = String(today.getMonth() + 3).padStart(2, '0'); //January is 0!
    let yyyy2 = today.getFullYear();
    
    let firstDate = yyyy1 + '-' + mm1 +  '-' + dd1 ;
    let secondDate = yyyy2 + '-' + mm2 +  '-' + dd2 ;

    let queryparams = new URLSearchParams();

    if (query.textField == ScraperSearchField.CaseNumber) {
        let a = query.textField.split('/')
        let b = a[0]+a[1]
        queryparams.append("caseNumber", b) 
    }
    else {
        queryparams.append("nameOfParty", query.text) 
    }
    queryparams.append("nameOfParty", query.text) // 
    //how to interprete all available dates

    queryparams.append("startDate", firstDate);
    queryparams.append("endDate",secondDate);
    queryparams.append("jurisdiction", "Civil");
    queryparams.append("offset", offset.toString())
    queryparams.append("count", count.toString())


    
    let url = "https://api.onlineregistry.justice.nsw.gov.au/courtlistsearch/listings?"
    let res = await fetch(url + queryparams.toString(), {
        headers: {
            'Content-Type': 'application/json'
        },

    })
    if (res.ok == false) {
        throw Error(`Bad status response while fetching search page: ${res.status} - ${res.statusText}`)
    }

    if (!res.body) throw Error('Response has no body');

    let resString = await res.text();

    let responseBody = JSON.parse(resString);

    /// extracting the cases as a CourtCase from the data provided 
    for (const hit of responseBody.hits) {
        let caseNumber = hit.scm_case_number
        let caseName = hit.case_title
        let jurisdiction = hit.scm_jurisdiction_type
        let url = "https://onlineregistry.lawlink.nsw.gov.au/content/court-lists#/detail/"+hit.id // caseid as a query parameter
        //extracting the parties names 
        
        let involved = []

        if(hit.parties.length <= 1){

            involved = caseName.split(' v ');
    
        } else{
            involved.push(hit.parties[0].party_name)
            involved.push(hit.parties[1].party_name)
        }
        //duplicates are coming from the NSW website 
        //if (!containsID(caseNumber)){
                results.push({
                id: caseNumber,
                title: caseName,
                proceedingsDetail: jurisdiction,
                locationState: 'NSW',
                url: url,
                parties: involved 
        })
    }

    totalHits = responseBody.total
    return {
        results:results,
        offset: responseBody.offset,
        limit: responseBody.count,
        total: totalHits
    }

    function containsID(string:String) {
        var i;
        for (i = 0; i < results.length; i++) {
            if (results[i].id===string) {
                return true;
            }
        }
    
        return false;
    }
} 
export default searchNSW