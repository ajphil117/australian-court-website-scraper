import { CourtCase } from "@aace/capstone-common/codegen/client";
import fetch, { Response } from "node-fetch";
import Scraper, { ScraperSearchQuery, ddMMYYYY, ScraperSearchField } from "./Scraper";
import * as cheerio from "cheerio";
import { baseStr } from "../AutoSearch";

const searchSA = async function (query: ScraperSearchQuery) {
    let results: CourtCase[] = [];

    // The SA site has no query params, the page simply loads all available cases at once
    // and all sorting/filtering/"pagination" is done via JS.

    let resultOffset = query.offset || 0;
    let resultLimit = query.limit || 10;

    // Make the request (fetch)
    let res = await fetch("https://www.courts.sa.gov.au/case-lists/all-cases", {
        method: "GET"
    });

    // Parse the results into CourtCase objects
    if (!res.ok) throw Error(`Bad status response while fetching search page: ${res.status} - ${res.statusText}`);
    if (!res.body) throw Error('Response has no body');

    // Since SA returns the whole dang database, we'll do some caching so we don't have to parse the same thing over and over
    if (
        cachedResults != null &&
        Date.now() - cachedResults.timestamp < 3 * 60 * 60 * 1000
        && cachedResults.contentLength === res.headers.get("Content-Length")
    ) {
        results = cachedResults.cases;
    } else {
        let $ = cheerio.load(await res.text());
        let resultsTableBody = $("table[id='table_1'] > tbody");
        for (let tr of resultsTableBody.children("tr")) {
            let tds = $("td", tr);
            let details = tds.map((i, el) => $(el).text()).toArray();

            let relativeUrl = $("a[href^='./case-details']", tr).first().attr('href');
            let url = "https://www.courts.sa.gov.au/case-lists" + relativeUrl?.slice(1); 

            let parties: string[];
            let vSplit = details[1].split(" v ");
            if (vSplit.length > 1) {
                // Name is of the form "plaintiff a, plaintiff b v defendant a, ... defendant n"
                parties = vSplit.flatMap(p => p.split(", ")).map(s => s.trim());
            } else {
                let names = details[1].split(", ");
                if (names.length == 2) {
                    // Name is just one person's name, of the form "LASTNAME, FIRSTNAME"
                    parties = [ (names[1] + " " + names[0]) ];
                } else {
                    // It's probably an organisation's name. Just add it as-is.
                    parties = [ details[1] ];
                }
            }

            results.push({
                id: details[2],
                title: details[1],
                url: url,
                parties: parties,
                locationState: 'SA'
            });
        }

        cachedResults = {
            cases: results,
            timestamp: Date.now(),
            contentLength: res.headers.get("Content-Length")! 
        };
    }

    let filter = (c: CourtCase) => true;
    if (query.textField === ScraperSearchField.CaseNumber) {
        filter = c => c.id.includes(query.text);
    } else {
        let baseQuery = baseStr(query.text);
        filter = c => baseStr(c.title!).includes(baseQuery);
    }

    results = results.filter(filter);
    return {
        results: results.slice(resultOffset, resultOffset + resultLimit),
        offset: resultOffset,
        limit: resultLimit,
        total: results.length
    };
}
export default searchSA;

let cachedResults: { cases: CourtCase[], timestamp: number, contentLength: string } | null = null;