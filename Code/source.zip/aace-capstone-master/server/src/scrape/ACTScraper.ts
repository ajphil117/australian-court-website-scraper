import { CourtCase } from "@aace/capstone-common/codegen/client";
import fetch, { Response } from "node-fetch";
import Scraper, { ScraperSearchQuery, ddMMYYYY, ScraperSearchField } from "./Scraper";
import * as cheerio from "cheerio";

export const searchACTMagistrates: Scraper = async function (query: ScraperSearchQuery) {
    return searchACT(query, "magistrates-court-lawlists");
};

export const searchACTSupreme: Scraper = async function (query: ScraperSearchQuery) {
    return searchACT(query, "supreme-court-lawlists");
};

const searchACT = async function (query: ScraperSearchQuery, collection: string) {
    let results: CourtCase[] = [];

    // Set up our query parameters (URLSearchParams)
    let urlQuery = new URLSearchParams({
        sort: "adate"
    });
    if (query.textField == ScraperSearchField.PartyPersonName || query.textField == ScraperSearchField.PartyOrganisationName) {
        urlQuery.append("meta_name", query.text);
    } else if (query.textField == ScraperSearchField.CaseNumber) {
        urlQuery.append("meta_caseNumber", query.text);
    }

    urlQuery.append("collection", collection);

    if (query.fromDate) {
        // urlQuery.append("dateAfter", ddMMYYYY(query.fromDate)); // JK the "dateAfter" field doesn't appear to do anything (?)
        urlQuery.append("meta_d3day", query.fromDate.getDate().toString());
        urlQuery.append("meta_d3month", months[query.fromDate.getMonth()]);
        urlQuery.append("meta_d3year", query.fromDate.getFullYear().toString());
    }

    let resultOffset = query.offset || 0;
    let resultLimit = query.limit || 10;
    if (resultLimit > 200) resultLimit = 200; // Max limit allowed by the website

    urlQuery.append("start_rank", (resultOffset + 1).toString()); // Server expects this to be 1-indexed
    urlQuery.append("num_ranks", resultLimit.toString());

    // Make the request (fetch)
    let res = await fetch("https://www.courts.act.gov.au/lists?" + urlQuery.toString(), {
        method: "GET"
    });

    // Parse the results into CourtCase objects
    if (!res.ok) throw Error(`Bad status response while fetching search page: ${res.status} - ${res.statusText}`);
    if (!res.body) throw Error('Response has no body');

    let $ = cheerio.load(await res.text());
    // "(1 - 50 of 1,331 listings)"
    let searchPageSummary = $("span[id='search-total-matching']").text().replace(/,/g, "").split(" ");
    let pageStart = parseInt(searchPageSummary[0].slice(1));
    let pageEnd = parseInt(searchPageSummary[2]);
    let totalResults = parseInt(searchPageSummary[4]);

    if (isNaN(totalResults)) {
        return {
            results: [], offset: resultOffset, limit: resultLimit, total: 0
        }
    }

    let resultsTableBody = $("table[id='search-results'] > tbody");
    for (let tr of resultsTableBody.children("tr")) {
        let details = $("td", tr).map((i, el) => $(el).text()).toArray();
        let parties: string[] = details[1].split(" v ").map(s => s.trim());
        results.push({
            title: details[1],
            url: "https://www.courts.act.gov.au/lists?meta_caseNumber=" + encodeURIComponent(details[0]),
            id: details[0],
            parties: parties,
            locationState: "ACT"
        });
    }

    return {
        results: results,
        offset: pageStart - 1, // From 1-indexed back to 0-indexed
        limit: resultLimit,
        total: totalResults
    };
}

const months = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ];