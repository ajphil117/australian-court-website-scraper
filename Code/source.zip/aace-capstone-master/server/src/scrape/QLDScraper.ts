// Scraper for QLD eCourts service
import fetch, { Response } from "node-fetch";
import * as cheerio from "cheerio";
import Scraper, { ScraperSearchField, ScraperSearchQuery, ddMMYYYY } from "./Scraper";
import { CourtCase } from "@aace/capstone-common/codegen/client";

const eCourtsPageSize = 20; // Max number of items that eCourts shows on a single page
const aspxTargetNextPage = "ctl00$ContentPlaceHolder1$FileGrid$ctl01$NextTopLink";
const searchQLD: Scraper = async function (query: ScraperSearchQuery) {

    let urlQuery = new URLSearchParams();
    if (query.textField == ScraperSearchField.PartyPersonName) {
        // Split the search string into given and last names - TODO: we'll replace this with specific fields later
        let names = query.text.split(" ");
        let givenNames = names.slice(0, -1);
        let lastName = names.slice(-1)[0];
        urlQuery.append("Givennames", givenNames.join(" "));
        urlQuery.append("Lastcompanyname", lastName)
    } else if (query.textField == ScraperSearchField.PartyOrganisationName) {
        urlQuery.append("Lastcompanyname", query.text);
    } else if (query.textField == ScraperSearchField.CaseNumber) {
        urlQuery.append("Filenumber", query.text);
    }

    if (query.fromDate) {
        urlQuery.append("Datefromlisting", ddMMYYYY(query.fromDate));
    }

    let resultLimit = query.limit || eCourtsPageSize;
    let resultOffset = query.offset || 0; 

    let aspxState: ASPXState = {};
    // Check if we have cached ASPX state on/before the requested offset
    let cachedPage = getCachedASPX(query);
    if (cachedPage && cachedPage.offset <= resultOffset) {
        aspxState = cachedPage.aspx;
        // Actually don't do below. I thought this would save us making a duplicate request when
        // we know the offset we want must be on the next page, but if we're on the last page 
        // and we set the event target to next page, it seems like it takes us backwards.
        // if (resultOffset >= cachedPage.offset + eCourtsPageSize) {
        //     aspxState["__EVENTTARGET"] = aspxTargetNextPage;
        // }
    };

    // Start making requests to fill the results array
    let resultsPage: CourtCase[] = [];
    let lastResult: Awaited<ReturnType<typeof parsePage>> | undefined = undefined;
    while (resultsPage.length < resultLimit) {
        let res = await fetch("http://apps.courts.qld.gov.au/esearching/Results.aspx?" + urlQuery.toString(), {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(aspxState)
        });
        let r = await parsePage(res);
        lastResult = r;
        if (resultOffset >= r.total) break;

        // console.info(`${query.text} - page ${r.offsetStart} to ${r.offsetEnd}`);
        if (r.offsetEnd >= resultOffset) {
            let start = resultsPage.length === 0 ? resultOffset % eCourtsPageSize : 0; // On the first page, start (offset % page size) into the results
            let end = resultLimit - resultsPage.length;
            resultsPage.push(...r.cases.slice(start, start + end))  
        }
        
        aspxState = r.aspx;
        // Set the ASPX event target to the "Next page" button for the next request
        aspxState["__EVENTTARGET"] = aspxTargetNextPage;

        if (r.total === r.offsetEnd + 1 || r.offsetEnd === -1) break; // This is the last page
    }

    // Save the last ASPX state we received. We'll use it to get to the next page (or this one again) if the client makes another request soon.
    if (lastResult) {
        delete aspxState["__EVENTTARGET"];
        cacheASPX(query, lastResult.offsetStart, aspxState);
    }

    return {
        results: resultsPage,
        offset: resultOffset,
        limit: resultLimit,
        total: lastResult ? lastResult.total : 0
    };
}
export default searchQLD;

/**
 * Implementing pagination on this scraper requires a little creativity.
 * The website doesn't include any request parameters to jump to a specific page.
 * The page number is instead encoded in the giant ASPX view state string, among other stuff.
 * Since we can't generate that string (we can only received an updated one when the user
 * clicks "next page"), we're unable to jump to page 10 if we haven't first been
 * through pages 1-9.
 * That's not too much of a problem though, because we usually want data in order anyway.
 * To save us from always starting back from page 1, we can cache the view states from
 * previous pages to use across requests.
 */
type CachedASPXState = { offset: number, aspx: ASPXState };
const ASPXPageCache = new Map<string, CachedASPXState>();
const CACHE_MAX_SIZE = 256;
const CACHE_FLUSH_MS = 5 * 60 * 1000; 
let flushCacheTimeout: NodeJS.Timeout | null = null;

function cacheASPX(query: ScraperSearchQuery, startOffset: number, aspx: ASPXState) {
    if (ASPXPageCache.size > CACHE_MAX_SIZE) {
        ASPXPageCache.delete(ASPXPageCache.keys().next().value);
    }

    ASPXPageCache.set(hashQuery(query), { offset: startOffset, aspx: aspx });

    if (flushCacheTimeout) clearTimeout(flushCacheTimeout);
    flushCacheTimeout = setTimeout(() => ASPXPageCache.clear(), CACHE_FLUSH_MS);
}

function getCachedASPX(query: ScraperSearchQuery): CachedASPXState | undefined {
    return ASPXPageCache.get(hashQuery(query));
}

/**
 * Empty the QLD eCourts ASPX cache now, and clear the flush timeout.
 */
export function flushQLDCache() {
    ASPXPageCache.clear();
    if (flushCacheTimeout) {
        clearTimeout(flushCacheTimeout);
        flushCacheTimeout = null;
    }
}

function hashQuery(query: ScraperSearchQuery): string {
    return query.text + query.textField + query.fromDate?.toISOString();
}

async function parsePage(response: Response) {
    if (!response.ok) throw Error(`Bad status response while fetching search page: ${response.status} - ${response.statusText}`);
    if (!response.body) throw Error('Response has no body');

    let results: CourtCase[] = [];
    let $ = cheerio.load(await response.text());
    let rootTable = $("table[id$='FileGrid'] > tbody");
    for (let tr of rootTable.children("tr[class!='GridPager']")) {
        let caseNumber = $("[id$='filenumber' i]", tr).text();
        let caseName = $("[id$='filename' i]", tr).text();

        if (caseNumber != "" && caseNumber != undefined) {
            let parties: PartyRow[] = [];
            let partyGrid = $("[id$='PartyGrid' i] > tbody", tr);
            for (let partyTr of partyGrid.children("tr[class!='GridHeader']")) {
                let partyDetails = $("td", partyTr).map((i, el) => $(el).text()).toArray();
                parties.push({
                    lastCompanyName: partyDetails[0].trim(),
                    firstNames: partyDetails[1].trim(),
                    proceedingType: partyDetails[2].trim(),
                    partyRole: partyDetails[3].trim(),
                    dateFiled: partyDetails[4].trim()
                });
            }
            
            // The link to the case details page isn't anywhere in the HTML. The web page usually makes another _doPostBack request
            // to find the case's URL. All the URLs are in the same format though, so instead of making an additional request for
            // each search result, we can build the URL ourselves.

            let originLocation = $("[id$='originatingLocation' i]", tr).text();
            let courtType = $("[id$=court]", tr).text();
            let url = response.url;
            try {
               url = `http://apps.courts.qld.gov.au/esearching/FileDetails.aspx?Location=${locationCodes[originLocation]}&Court=${courtCodes[courtType]}&Filenumber=${caseNumber}`;
            } catch (ex) {
                console.warn("[QLDScraper] Failed to create view URL for case with ID " + caseNumber, ex);
            }

            results.push({
                id: caseNumber,
                title: caseName,
                proceedingsDetail: parties[0].proceedingType,
                locationState: 'QLD',
                url: url,
                parties: parties.map(p => {
                    if (p.firstNames != "") return p.firstNames + " " + p.lastCompanyName;
                    return p.lastCompanyName;
                })
            });
        }
    }

    // Grab the ASPX VIEWSTATE fields out of the HTML. They are required to access the next page of results.
    let aspx = {
        __VIEWSTATE: $("input[id='__VIEWSTATE']").attr('value') || '',
        __VIEWSTATEGENERATOR: $("input[id='__VIEWSTATEGENERATOR']").attr('value') || '',
        __VIEWSTATEENCRYPTED: $("input[id='__VIEWSTATEENCRYPTED']").attr('value') || ''
    }

    let strStartToEndOfTotal = $("span[id$='recordcounts' i]").text().split(" "); // e.g. "1 - 20 of 500"
    if (strStartToEndOfTotal.length !== 5) throw Error("Parsing error: Unable to find total number of records");
    let offsetStart = parseInt(strStartToEndOfTotal[0]) - 1;
    let offsetEnd = parseInt(strStartToEndOfTotal[2]) - 1;
    let total = parseInt(strStartToEndOfTotal[4]);

    return {
        // eCourts will fill the array with extra garbage data when we use our cached ASPX
        // to request the last page (e.g. page should only be 5 items long, but there are 20 items returned). 
        // We need to explicitly ignore any results beyond the bounds of the page.
        cases: results.slice(0, offsetEnd - offsetStart + 1), 
        aspx: aspx,
        total: total,
        offsetStart: offsetStart,
        offsetEnd: offsetEnd
    }
}

type ASPXState = {
    [aspxProp: string]: string,
    //__EVENTTARGET?: string,
    //__VIEWSTATEGENERATOR?: string,
    //__VIEWSTATE?: string,
    //__EVENTARGUMENT?: string,
    //__VIEWSTATEENCRYPTED?: string
}
// Details included in each party row of the eCourts search results
type PartyRow = {
    lastCompanyName: string,
    firstNames: string,
    proceedingType: string,
    partyRole: string,
    dateFiled: string
}

const locationCodes: {[fullLocation: string]: string}= {
    "Beenleigh": "BEEN",
    "Bowen": "BOWN",
    "Brisbane": "BRISB",
    "Bundaberg": "BUN",
    "Cairns": "CRNS",
    "Charleville": "CHAR",
    "Charters Towers": "CHRT",
    "Cloncurry": "CLON",
    "Cunnamulla": "CUN",
    "Dalby": "DALB",
    "Emerald": "EMLD",
    "Gladstone": "GLAD",
    "Goondiwindi": "GWI",
    "Gympie": "GYMP",
    "Hervey Bay": "HERB",
    "Innisfail": "INFL",
    "Ipswich": "IPS",
    "Kingaroy": "KING",
    "Longreach": "LONG",
    "Mackay": "MCKY",
    "Maroochydore": "MDORE",
    "Maryborough": "MBGH",
    "Mt Isa": "MISA",
    "Rockhampton": "ROCK",
    "Roma": "ROMA",
    "Southport": "STHP",
    "Stanthorpe": "STAN",
    "Toowoomba": "TMBA",
    "Townsville": "TOWNS",
    "Warwick": "WARW"
}

const courtCodes: {[fullCourt: string]: string} = {
    "Supreme": "SUPRE",
    "District": "DISTR"
}