import fetch from "node-fetch";
import Scraper, { ScraperSearchField, ScraperSearchQuery } from "./Scraper"
import { CourtCase } from "@aace/capstone-common/codegen/client";

const vicscraper: Scraper = async function (query: ScraperSearchQuery) {
  let cases: CourtCase[] = [];


  const json: any =
  {
    CaseID: "",
    CaseType: "CIV",
    CourtLinkCaseNo: "",
    PlaintiffInformantApplicant: "",
    DefendantAccusedRespondent: "",
    Court: "",
    HearingDateTime: "",
    HearingType: "",
    OnlineHearing: "",
    AVLLink: "",
    InformantDivision: "",
    page: 1,
    pageSize: query.limit! || 0
  }

  if (query.offset! > 0) {
    json["pageSize"] = query.limit! + query.offset!
  }

  if (query.textField == ScraperSearchField.PartyOrganisationName || query.textField == ScraperSearchField.PartyPersonName) {
    json["DefendantAccusedRespondent"] = query.text
  } else {
    json["CaseID"] = query.text
  }

  //Perform the fetch of data
  const res = await fetch('https://dailylists.magistratesvic.com.au/EFAS/CaseSearch_GridData', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(json)
  })

  //Error catching
  if (res.ok == false) {
    throw Error(`Bad status response while fetching search page: ${res.status} - ${res.statusText}`)
  }

  if (!res.body) throw Error('Response has no body');
  const responseBody = await res.json()

  //For loop for Data formatting of cases
  for (var product of Object(responseBody.Data)) {

    // Define Case ID
    let ID: string = JSON.stringify(product.CaseID)

    //Grab plaintiff name and split into First and last
    var plaintiff: string = product.PlaintiffInformantApplicant
    if (plaintiff.includes(",") == true) {
      var plaintiffFirst: string = plaintiff.split(",")[1]
      var plaintifflast: string = plaintiff.split(" ")[0]
      plaintiff = plaintiffFirst.concat(" ", plaintifflast).trim()
      plaintiff = plaintiff.replace(/,/g, '');
    }

    // Grab defendant name and split into First and Last
    var defendant: string = product.DefendantAccusedRespondent
    if (defendant.includes(",") == true) {
      var defendantFirst: string = defendant.split(",")[1]
      var defendantlast: string = defendant.split(" ")[0]
      defendant = defendantFirst.concat(" ", defendantlast).trim()
      defendant = defendant.replace(/,/g, '');
    }

    //Create array of parties involved
    var parties: string[] = [plaintiff, defendant]

    //Create link to case details
    var url: string = `https://dailylists.magistratesvic.com.au/EFAS/Case${product.CaseType}?CaseID=${product.CaseID}`

    //define courtcase array

    cases.push(
      {
        "id": ID,
        "locationState": 'VIC',
        "url": url,
        "parties": parties,
        friendlyName: parties[0].length > 0 && parties[1].length > 0 ? parties[0] + ' v ' + parties[1] : parties[0]
      })
  }

  var totalLength = responseBody.Total

  return {
    results: cases.slice(query.offset!),
    offset: query.offset || 0,
    limit: query.limit || 0,
    total: totalLength,
  }

}

export default vicscraper;
