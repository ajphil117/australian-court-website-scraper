import { CourtCase } from "@aace/capstone-common/codegen/client";
export default interface Scraper {
    (query: ScraperSearchQuery): Promise<ScraperSearchResults>;
}

export type ScraperSearchQuery = {
    text: string,
    textField: ScraperSearchField,
    fromDate?: Date,
    
    // Pagination properties
    offset?: number,
    limit?: number
}

export type ScraperSearchResults = {
    /**
     * Cases returned from this search.
     */
    results: CourtCase[],
    /**
     * (Pagination) Offset of the first case in this result from the start of the full result set.
     */
    offset: number,
    /**
     * (Pagination) Limit on number of cases that was applied for this search request.
     */
    limit: number,
    /**
     * (Pagination) Total number of cases available in the full result set.
     */
    total: number
}

export enum ScraperSearchField {
    CaseNumber = "number", 
    PartyPersonName = "person", 
    PartyOrganisationName = "org"
}

export function ddMMYYYY(date: Date): string {
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
}