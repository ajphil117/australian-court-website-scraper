// Automatic searching function
// Routinely runs searches for auditors across all state databases.

import { Auditor, CourtCase } from "@aace/capstone-common/codegen/client";
import { db, DB_COLLECTION_AUDITORS, DB_COLLECTION_CASES, DB_COLLECTION_HEALTH } from ".";
import Scraper, { ScraperSearchField, ScraperSearchQuery } from "./scrape/Scraper";
import { courtCaseToDB, DB_CourtCase } from "./types/DB_CourtCase";
import { DB_HealthReport } from "./types/DB_HealthReport";

const SCRAPE_BATCH_SIZE = 8;
const scraperFuncs: Map<string, Scraper> = new Map();

let nextRun: NodeJS.Timeout | null = null;
let runTimes: Date[] = [];

export async function doSearch() {
    if (!isAutoSearchEnabled()) {
        console.warn('[AutoSearch] AutoSearch is not enabled. Skipping this doSearch call');
        return;
    }

    let report: DB_HealthReport = {
        lastAutoSearch: {
            completed: false,
            hits: 0, misses: 0,
            timestamp: new Date(),
            scrapers: {}
    
        }
    }
    scraperFuncs.forEach((s, name) => report.lastAutoSearch.scrapers[name] = { results: 0, failures: 0 });

    try {
        let auditors = await db().collection(DB_COLLECTION_AUDITORS).find<Auditor>({}).toArray();
        console.info(`[AutoSearch] Running automatic search for ${auditors.length} auditor(s) with ${scraperFuncs.size} scraper(s)`);
        let startTime = Date.now();

        let thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        let scrapeOptions: Partial<ScraperSearchQuery> = { fromDate: thirtyDaysAgo, offset: 0, limit: 50 }; // This is the limit PER SCRAPER

        type ScrapeResult = Promise<{ scraperName: string, forAuditor: Auditor, results?: CourtCase[], err?: any }>;
        let scrapes: (() => ScrapeResult)[] = [];
        for (let a of auditors) {
            for (let [name, scrape] of scraperFuncs) {
                let makeScrape = (s: ReturnType<Scraper>) => (
                    s.then(r => ({
                        scraperName: name, forAuditor: a,
                        results: r.results
                    })).catch(err => { 
                        throw {
                            scraperName: name, forAuditor: a,
                            err: err
                        }
                    })
                );

                if (a.givenNames || a.lastName) {
                    // TODO: Split the search into two separate fields for given and last names
                    scrapes.push(
                        () => makeScrape(scrape({ text: (a.givenNames + " " + a.lastName).trim(), textField: ScraperSearchField.PartyPersonName, ...scrapeOptions }))
                    );
                }
                if (a.organisation) {
                    let o = a.organisation;
                    scrapes.push(
                        () => makeScrape(scrape({ text: o, textField: ScraperSearchField.PartyOrganisationName, ...scrapeOptions }))
                    );
                }
            }
        }

        let results: PromiseSettledResult<Awaited<ScrapeResult>>[] = [];
        console.info(`[AutoSearch] Splitting ${scrapes.length} required scrapes into ${Math.ceil(scrapes.length / SCRAPE_BATCH_SIZE)} batches of ${SCRAPE_BATCH_SIZE}`);

        for (let i = 0; i < scrapes.length; i+=SCRAPE_BATCH_SIZE) {
            let promises: ScrapeResult[] = [];
            scrapes.slice(i, i + SCRAPE_BATCH_SIZE).forEach( s => promises.push(s()));
            results.push(...(await Promise.allSettled(promises)));
        }
        console.info(`[AutoSearch] Processing ${results.length} results`);

        let nFailures = 0; let nWhiffs = 0;
        for (let r of results) {
            if (r.status == 'rejected') {
                let forAuditor = r.reason.forAuditor ? r.reason.forAuditor.id : 'unknown';
                console.warn(`[AutoSearch] Error for scraper ${r.reason.scraperName} searching for auditor ${forAuditor}`, r.reason.err);
                report.lastAutoSearch.scrapers[r.reason.scraperName].failures++;
                nFailures++;
                continue;
            }
            if (!scraperFuncs.has(r.value.scraperName)) continue; // This scraper has been removed from the auto list - discard its results
            if (r.value.results!.length === 0) { nWhiffs++; continue; }
            
            for (let rCase of r.value.results!) {
                report.lastAutoSearch.scrapers[r.value.scraperName].results++;

                let auditor = r.value.forAuditor;
                rCase.firstFound = new Date().toISOString();
                // Link the auditor with one of the parties in the case (taggedAuditors)
                let foundAuditor = false;
                for (let party of rCase.parties) {
                    let pStr = baseStr(party);
                    let matched = false;

                    // Need to leave a note to users ensuring that full names are used (e.g. Bradley vs Brad)
                    if (auditor.lastName) {
                        if (auditor.givenNames) {
                            matched = nameMatch(pStr, auditor.givenNames, auditor.lastName); 
                        } else {
                            matched = pStr.includes(baseStr(auditor.lastName));
                        }
                    }
                    if (auditor.organisation) {
                        let baseOrg = baseStr(auditor.organisation);
                        matched = matched || pStr.includes(baseOrg) || (pStr.length > 3 && baseOrg.includes(pStr));
                    }

                    if (matched) {
                        if (rCase.taggedAuditors == undefined) rCase.taggedAuditors = {};
                        rCase.taggedAuditors[auditor.id] = party;
                        foundAuditor = true;
                        break;
                    }
                }
                if (!foundAuditor) { report.lastAutoSearch.misses++; continue; }

                let cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
                
                let rFilter = { id: rCase.id, locationState: rCase.locationState };
                let { url, taggedAuditors, parties, ...setOnInsertProps} = courtCaseToDB(rCase);
                await cases.updateOne(rFilter, {
                    $setOnInsert: {
                        ...setOnInsertProps
                    },
                    $set: { // These properties are the only ones that we update when a case is found again
                        url: rCase.url,
                        // Add/overwrite keys in taggedAuditors without replacing the whole object
                        // (creates a bunch of "taggedAuditors.keyToInsert")
                        ...Object.keys(rCase.taggedAuditors || {}).reduce(
                            (aObj, key) => ({...aObj, ['taggedAuditors.' + key]: rCase.taggedAuditors![key]}), {}
                        )
                    },
                    $addToSet: {
                        parties: { $each: rCase.parties }
                    }
                }, { upsert: true });
                report.lastAutoSearch.hits++;
            }
        }
        
        report.lastAutoSearch.completed = true;
        console.info(`[AutoSearch] completed in ${(Date.now() - startTime) / 1000}s with ${report.lastAutoSearch.hits} hits, ${report.lastAutoSearch.misses} misses, ${nWhiffs} total whiffs, and ${nFailures} failures`);
    } catch (ex: any) {
        console.error("[AutoSearch] Exception prevented the automatic search from completing", ex);
        report.lastAutoSearch.completed = false;
        report.lastAutoSearch.errorMessage = ex.message || JSON.stringify(ex);
    } finally {
        // Log a health report for this run
        const health = db().collection<DB_HealthReport>(DB_COLLECTION_HEALTH);
        health.insertOne(report); // health is a capped collection: MongoDB will automatically remove the oldest records if it gets too big
    }

    scheduleNextSearch();
}

/**
 * Enable automatic searches. Searches will run daily at the times set by setSearchTimes using the
 * scrapers set by setScrapers.
 * @param times A list of times to run a search at each day. Times are specified as Date objects,
 * but only the hours and minutes fields are considered.
 * @param scrapers List of scrapers to include in automatic searchers.
 */
export function enableAutoSearch(times: Date[], scrapers: { name: string, scraper: Scraper }[], searchNow: boolean = false) {
    runTimes = times.map(d => new Date(d));
    scraperFuncs.clear();
    scrapers.forEach(s => scraperFuncs.set(s.name, s.scraper)); 
    
    scheduleNextSearch();
    console.info('[AutoSearch] Automatic search enabled');

    if (searchNow) {
        doSearch();
    }
}

export function isAutoSearchEnabled(): boolean {
    return nextRun !== null;
}

function scheduleNextSearch() {
    // Find the next closest run time
    let now = new Date();
    let minInterval = Number.MAX_VALUE;
    let minDate = null;

    for (let time of runTimes) {
        time.setFullYear(now.getFullYear(), now.getMonth(), now.getDate());
        time.setSeconds(0, 0);
        // If the time has already passed today, consider it for tomorrow
        if (+time - +now < 0) {
            time.setDate(time.getDate() + 1);
        }
        let interval = +time - +now;
        if (interval < minInterval) {
            minInterval = interval;
            minDate = time;
        }
    }
    if (minDate == null) return;

    if (nextRun != null) clearTimeout(nextRun);
    nextRun = setTimeout(doSearch, minInterval);
    console.info(`[AutoSearch] Next automatic search scheduled for ${minDate}`);
}

/**
 * Stop automatic searches. The results of any automatic searches currently running will be lost.
 */
export function disableAutoSearch() {
    if (nextRun != null) {
        clearTimeout(nextRun);
        nextRun = null;
    }
    // We can't actually cancel promises, so we just delete them from the scraperFuncs map. The callbacks
    // for each scraper are set to check if they still exist in scraperFuncs and, if not, discard their results.
    scraperFuncs.clear();
    console.info("[AutoSearch] Automatic searches disabled");
}

export function nameMatch(test: string, givenNames: string, lastName: string) : boolean {
    // TODO: Confirm that none of our data is LASTNAME, First name. That format would fail this check
    // Check for first name, one or more whitespaces/digits/other words, and
    // then the last name as its own word.
    return new RegExp(`${baseStr(givenNames.split(' ')[0])}[\\w\\d\\s]+\\b${baseStr(lastName)}\\b`).test(test);
}

export function baseStr(str: string) {
    // Removing symbols like - and . helps with matching company names.
    // Also, we remove descriptors like PTY and LTD so that they aren't required to match
    return str.toLowerCase()
           .replace(/[-'".():]/g, '')
           .replace(/ limited /g, " ")
           .replace(/ proprietary /g, " ")
           .replace(/ incorporated /g, " ")
           .replace(/ ltd /g, " ")
           .replace(/ pty /g, " ")
           .replace(/ inc /g, " ")
           .trim();
}