import { db, DB_COLLECTION_SETTINGS, openDBConnection } from ".";
import { hashPassword, makeSalt } from "./PasswordHash";
import { DB_Setting, SETTING_PASSWORD } from "./types/DB_Setting";

// Runs when the program is started with the resetPassword command
export default async function resetPasswordCommand(args: any, openDatabase: () => ReturnType<typeof openDBConnection> ) {
    if (!args.password || args.password.length < 10) {
        throw Error("Password must be at least 8 characters in length.");
    }

    let o = openDatabase();
    try {
        await o.ready;

        let salt = await makeSalt();
        let hash = await hashPassword(args.password, salt);

        const settings = db().collection<DB_Setting>(DB_COLLECTION_SETTINGS);
        let filter = { key: SETTING_PASSWORD };
        let update = { 
            $setOnInsert: {
                key: SETTING_PASSWORD
            },
            $set: {
                hash: hash, salt: salt
            }
        };
        let result = await settings.updateOne(filter, update, { upsert: true });
        
        if (result.acknowledged) {
            console.info("Successfully updated group password");
        } else {
            throw Error("Failed to update password: the database did not acknowledge the update.");
        }
    } finally {
        if (o) {
            o.client.close();
        }
    }
}