const nodeCrypto = import('node:crypto');

export async function hashPassword(userPassword: string, salt: Buffer): Promise<Buffer> {
    let c = await nodeCrypto;
    let password = Buffer.from(userPassword.normalize(), 'utf-8');
    return new Promise((resolve, reject) => {
        c.scrypt(password, salt, 64, (err, derivedKey) => {
            if (err) {
                reject(err);
                return;
            }

            resolve(derivedKey);
        });
    });
}

export async function makeSalt(): Promise<Buffer> {
    let c = await nodeCrypto;
    return new Promise((resolve, reject) => {
        c.randomBytes(16, (err, buf) => {
            if (err) {
                reject(err);
                return;
            }

            resolve(buf);
        })
    });
}