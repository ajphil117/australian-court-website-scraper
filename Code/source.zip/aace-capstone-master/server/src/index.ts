import { Auditor, CourtCase, UserAccount } from "@aace/capstone-common/codegen/client";
import cors from "cors";
import * as dotenv from 'dotenv';
import type { ErrorRequestHandler } from "express";
import express from "express";
import { initialize } from "express-openapi";
import * as fs from 'fs';
import type { Server } from "http";
import { Db, Filter, MongoClient, MongoClientOptions } from "mongodb";
import type { SecurityHandler } from "openapi-security-handler";
import type { OpenAPI } from "openapi-types";
import yargs from "yargs";
import { getSettingAutoSearch } from "./api/paths/settings/autosearch";
import { getSettingEmails } from "./api/paths/settings/emails";
import { disableAutoSearch, enableAutoSearch } from "./AutoSearch";
import { closeMailer, initMailer, MailerConfig } from "./Mailer";
import { hashPassword } from "./PasswordHash";
import resetPasswordCommand from "./PasswordReset";
import { searchACTMagistrates, searchACTSupreme } from "./scrape/ACTScraper";
import searchNSW from "./scrape/NSWScraper";
import searchNT from "./scrape/NTScraper";
import searchQLD, { flushQLDCache } from "./scrape/QLDScraper";
import searchSA from "./scrape/SAScraper";
import Scraper from "./scrape/Scraper";
import vicscraper from "./scrape/VICscraper";
import { DB_HealthReport } from "./types/DB_HealthReport";
import { DB_MailLog } from "./types/DB_MailLog";
import { DB_Setting, SettingPassword, SETTING_PASSWORD } from "./types/DB_Setting";
const mergeAPIDoc = require("@aace/capstone-common/scripts/MergeApiDoc.js");
const path = require('path');
dotenv.config();

const inProduction = process.env.NODE_ENV === 'production';
export const DB_COLLECTION_AUDITORS = "auditors";
export const DB_COLLECTION_CASES = "cases";
export const DB_COLLECTION_REVIEWS = "case_reviews";
export const DB_COLLECTION_USERS = "users";
export const DB_COLLECTION_SETTINGS = "settings";
export const DB_COLLECTION_HEALTH = "health";
export const DB_COLLECTION_MAIL_LOGS = "mail_logs";

export const AllScrapers: { [state: string]: {name: string, scraper: Scraper} } = {
    "QLD": { name: "QLD eCourts", scraper: searchQLD },
    "ACT": { name: "ACT Magistrates hearing list", scraper: searchACTMagistrates},
    "ACT-SUPREME": { name: "ACT Supreme hearing list", scraper: searchACTSupreme },
    "NT": { name: "NT daily list", scraper: searchNT },
    "VIC": { name: "VIC Magistrates Search", scraper: vicscraper},
    "SA": { name: "SA hearing list", scraper: searchSA },
    "NSW": {name: "NSW Online", scraper: searchNSW}
};

export let db: () => Db = () => { throw new Error("The database connection hasn't been initialised.") };

export type ServerLaunchConfig = {
    port: number, 
    mongoDBName: string, mongoUrl: string, 
    mailerConfig: MailerConfig, 
    corsOrigin?: string,
    webClientPath?: string, 
    apiHandlerPath?: string
}
export type ServerStuff = { server: Server, mongo: MongoClient, startupDone: Promise<[void, void]>, shutdown: () => Promise<[PromiseSettledResult<void>, PromiseSettledResult<void>]> };
/**
 * Launch the AACE capstone server. This will start the Express web server, deploy the API endpoints and the web client, and
 * connect to the MongoDB database.
 * 
 * @param port Port the server should listen on.
 * @param mongoDBName Name of the database to work in when connected to the MongoDB server.
 * @param mongoUrl URL of the MongoDB server to connect to, including login details if required.
 * @param apiHandlerPath File path to the folder containing the endpoint handlers for the API. Defaults to "{__dirname}/api/paths".
 * @returns ServerStuff object containing initialised server stuff and a shutdown() function.
 */
export async function launch(config: ServerLaunchConfig): Promise<ServerStuff> {
    const { port, mongoDBName, mongoUrl, mailerConfig, webClientPath, apiHandlerPath } = config;
    console.info("--- AACE-capstone server ---");
    if (!inProduction) console.warn("Running in development mode");

    console.info("Starting web server...");
    const app = express();
    app.use(cors({
        origin: config.corsOrigin || ('http://localhost' + (!inProduction && ':3000'))
    }));
    app.use(express.json());

    const checkHttpAuth = async (req: OpenAPI.Request) => {
        let h = req.headers as any | undefined;
        if (!h?.authorization) return { passwordValid: false };
        // Should be of the form "Basic <base64 encoded username:password>"
        let auth = h.authorization.split(' ', 2);
        if (auth.length < 2 || auth[0] != 'Basic') return { passwordValid: false };
        let b = Buffer.from(auth[1], 'base64');
        let userPass = b.toString('ascii').split(':', 2);
        if (userPass.length !== 2) return { passwordValid: false };
        let user = userPass[0];
        let password = userPass[1];

        const settings = db().collection<DB_Setting>(DB_COLLECTION_SETTINGS);
        let passwordSetting = await settings.findOne({ key: SETTING_PASSWORD }) as SettingPassword | null;
        if (!passwordSetting) throw { status: 503, errorCode: 'nopassword', message: 'No group password has been set for this server. Refer to the documentation for instructions.' };

        let inputHash = await hashPassword(password, passwordSetting.salt.buffer);

        return { 
            user: user, password: password,
            passwordValid: inputHash.equals(passwordSetting.hash.buffer) 
        }
    }

    // Requires the group password encoded according to HTTP Basic auth, with the username set to "?"
    const groupPasswordSecurityHandler: SecurityHandler = async (req, scopes, definition): Promise<boolean> => {
        let check;
        try {
            check = await checkHttpAuth(req);
        } catch (err) {
            throw err;
        }

        if (check.user != '?') return false;
        return check.passwordValid;
    }

    // Requires a username and password encoded according to HTTP Basic auth
    const groupUserSecurityHandler: SecurityHandler = async (req, scopes, definition): Promise<boolean> => {
        let check;
        try {
            check = await checkHttpAuth(req);
        } catch (err) {
            throw err;
        }

        if (!check.passwordValid) return false;
        // Check that the provided user ID is valid
        const users = db().collection<UserAccount>(DB_COLLECTION_USERS);
        let filter: Filter<UserAccount> = { id: check.user };

        let result = await users.findOne(filter, {});
        if (result == null) return false;
        (req as any).user = result; // Attach user to req object, so middleware will be able to access

        return true;
    }

    const globalErrorHandler: ErrorRequestHandler = (err, req, res, next) => {
        if (err.status != undefined && err.errorCode != undefined || err.errors != undefined) {
            // Errors generated by express-openapi end up here for some reason
            res.status(err.status).json(err).send();
            return;
        };
        if (err.statusCode === 400 || res.statusCode === 400) {
            if (err.type === 'entity.parse.failed') {
                // JSON parser error
                res.status(400).json({
                    status: 400,
                    errors: [
                        {
                            errorCode: 'json.parse-failed',
                            message: 'failed to parse json body'
                        }
                    ]
                });
            } else {
                // Generic user error
                res.status(400).send();
            }
            return;
        }
        console.error(`Error in an express handler for route ${req.url}`, err);
        if (res.headersSent) {
            return next(err);
        }

        if (res.statusCode === 503 || err.name === 'MongoTopologyClosedError') {
            // Indicates the handler had problems talking to the database
            res.status(503).send("Unable to contact the database")
        } else {
            res.status(500).send("An internal server error occurred.");
        }
    };

    await initialize({
        app,
        apiDoc: mergeAPIDoc(),
        paths: apiHandlerPath || path.join(__dirname, "./api/paths"),
        docsPath: '/docs',
        exposeApiDocs: !inProduction,
        securityHandlers: { 
            BasicGroupUserPass: groupUserSecurityHandler,
            BasicGroupPass: groupPasswordSecurityHandler
        },
        errorMiddleware: globalErrorHandler
    });

    if (!inProduction) {
        app.use('/swagger', express.static(require('swagger-ui-dist').absolutePath()))
    }

    // Serve static web client
    if (webClientPath) {
        console.info('Serving web client from ', webClientPath);
        app.use(express.static(webClientPath));
        app.get("/*", (req, res) => {
            res.sendFile(path.join(webClientPath, 'index.html'));
        });
    }


    let expressReadyResolve: () => void, expressReadyReject: (err?: any) => void;
    let expressReady: Promise<void> = new Promise((res, rej) => { expressReadyResolve = res; expressReadyReject = rej; });
    const server = app.listen(port);
    server.on('listening', () => console.info(`Web server listening on port ${port}`));
    server.on('listening', () => expressReadyResolve());

    let openDB = openDBConnection(mongoUrl, mongoDBName);
    let mongo = openDB.client;
    let mongoReady = openDB.ready;

    mongoReady.then(async () => {
        // Set up the automatic search
        try {
            let s = await getSettingAutoSearch();
            if (s.autoSearchEnabled) {
                enableAutoSearch([morn, aft], Object.values(AllScrapers), true);
            }
        } catch (err) {
            console.error('Error enabling auto search', err);
        }
    
        // Init email transport
        try {
            MailerConfiguration = mailerConfig;
            let s = await getSettingEmails();
            if (s.notificationsEnabled) {
                initMailer(mailerConfig);
            }
        } catch (err) {
            // No biggie; the mailer will automatically try to re-init when we want to send a message.
            console.error('[Mailer] Failed to initialize email transport', err);
        }
    });

    async function shutdown() {
        disableAutoSearch();
        closeMailer();
        flushQLDCache();

        let expressClosedResolve: () => void, expressClosedReject: (err?: any) => void;
        let expressClosed: Promise<void> = new Promise((res, rej) => { expressClosedResolve = res; expressClosedReject = rej; });
        server.close((err) => err ? expressClosedReject(err) : expressClosedResolve());
        return Promise.allSettled([ 
            expressClosed.then(() => console.info('Closed web server')), 
            mongo.close(true).then(() => console.info('Closed database connection'))
        ]);
    }

    return {
        server: server,
        mongo: mongo,
        startupDone: Promise.all([ expressReady, mongoReady ]),
        shutdown: shutdown
    };
}
// TODO: Attempt to reconnect if connection failed (Mongo will automatically do this if the connection drops, but not if it never opens).
// Alternatively, just crash if there's no database at startup?
export function openDBConnection(mongoUrl: string, mongoDBName: string) {
    console.info(`Opening database connection to "${mongoUrl}"...`);
    const dbTimeoutMs = inProduction ? 10000 : 1000;
    const mongoOpts: MongoClientOptions = {
        socketTimeoutMS: dbTimeoutMs,
        connectTimeoutMS: dbTimeoutMs,
        serverSelectionTimeoutMS: dbTimeoutMs
    }
    const mongo = new MongoClient(mongoUrl, mongoOpts);
    db = () => mongo.db(mongoDBName);

    let mongoReadyResolve: () => void, mongoReadyReject: (err?: any) => void;
    let mongoReady: Promise<void> = new Promise((res, rej) => { mongoReadyResolve = res; mongoReadyReject = rej; });
    mongo.connect().then(async () => {
        try {
            // TODO: Remove this ping, just throw the error. Then in the catch for the promise,
            // try reconnect after a 10s delay
            await mongo.db(mongoDBName).command({ ping: 1 });
            console.info(`Connected to database: using ${mongoDBName}`);
        } catch (err) {
            console.error("Failed to ping database", err);
            mongoReadyReject(err);
            return;
        }

        const db = () => mongo.db(mongoDBName);
        // Database setup (these commands will do nothing if the database is already configured)
        await db().collection<CourtCase>(DB_COLLECTION_CASES).createIndex({ id: 1, locationState: 1 }, { unique: true });
        await db().collection<Auditor>(DB_COLLECTION_AUDITORS).createIndex({ id: 1 }, { unique: true });
        await db().collection(DB_COLLECTION_SETTINGS).createIndex({ key: 1 }, { unique: true });
        await db().collection<UserAccount>(DB_COLLECTION_USERS).createIndex({ name: "text" });
        let healthCreated = false;
        try {
            healthCreated = await db().collection<DB_HealthReport>(DB_COLLECTION_HEALTH).isCapped();
        } catch (ex) {} // Will fail if the db doesn't exist
        if (!healthCreated) {
            await db().createCollection(DB_COLLECTION_HEALTH, { capped: true, size: 2000000 });
        }
        let mailLogsCreated = false;
        try {
            mailLogsCreated = await db().collection<DB_MailLog>(DB_COLLECTION_MAIL_LOGS).isCapped();
        } catch (ex) {} // Will fail if the db doesn't exist
        if (!mailLogsCreated) {
            await db().createCollection(DB_COLLECTION_MAIL_LOGS, { capped: true, size: 2000000, max: 100 });
        }

        mongoReadyResolve();

    }).catch(err => console.error("Failed to open database connection", err));

    return { client: mongo, ready: mongoReady };
}

if (require.main === module) {
    const commandLineLaunch = async () => {
        const mongoDBName = inProduction ? 'aace-capstone' : 'dev-aace-capstone';
        const mongoUrl = process.env.MONGO_URL || "mongodb://localhost:27017";

        const mailHost = process.env.SMTP_HOST || 'localhost';
        const mailConfig: MailerConfig = {
            host: mailHost, 
            port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
            username: process.env.SMTP_USER, password: process.env.SMTP_PASS,
            fromAddress: process.env.SMTP_FROM_EMAIL || 'aace_court_watchdog@' + mailHost,
            tlsAllowSelfSigned: process.env.SMTP_ALLOW_SELF_SIGNED === 'true', 
        }
        
        let webClientPath = process.env.WEB_CLIENT_PATH;
        if (webClientPath === undefined) {
            try {
                let defaultPath = path.join(__dirname, '/webclient');
                await fs.promises.access(path.join(defaultPath, 'index.html'));
                webClientPath = defaultPath;
            } catch (ex) {}
        }
        
        const args = await yargs //NOTE: This await *does* have an effect on this statement (yargs returns a promise if any of the commands are async).
            .option("port", {
                description: "Port the web server will listen on",
                default: 80
            })
            .command(
                'resetPassword <password>', 
                'Reset the group password. The password will be updated in the database and the program will exit.', {},
                async (a: any) => await resetPasswordCommand(a, () => openDBConnection(mongoUrl, mongoDBName))
            )
            .help()
            .showHelpOnFail(false)
            .strict()
            .argv;

        if (args._.length > 0) return; // A command was run - don't start the server

        let s = await launch({ 
            port: process.env.PORT ? parseInt(process.env.PORT) : args.port, 
            mongoDBName: mongoDBName, 
            mongoUrl: mongoUrl, 
            mailerConfig: mailConfig, 
            webClientPath: webClientPath,
            corsOrigin: process.env.CORS_ORIGIN
        });
        async function shutdown(signal: string) {
            console.info(`Received ${signal} - shutting down...`);
            let [ expressStatus, mongoStatus ] = await s.shutdown();
            if (expressStatus.status === 'rejected') {
                console.error('Error while closing web server', expressStatus.reason);
            }
            if (mongoStatus.status === 'rejected') {
                console.error('Error while closing database connection', mongoStatus.reason);
            }
            process.exit(0);
        }

        process.on('SIGTERM', shutdown);
        process.on('SIGINT', shutdown);
    };
    commandLineLaunch();
}

let morn = new Date();
morn.setHours(10, 0);
let aft = new Date();
aft.setHours(16, 0);
export const AutoSearchHours = [
    morn, aft
]

/**
 * Readonly - the mail config supplied when the server was launched.
 */
export let MailerConfiguration: MailerConfig | null = null;