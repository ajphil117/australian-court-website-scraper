import { UserAccount } from '@aace/capstone-common/codegen/client';
import { Document, Filter } from 'mongodb';
import * as nodemailer from 'nodemailer';
import { db, DB_COLLECTION_CASES, DB_COLLECTION_MAIL_LOGS, DB_COLLECTION_USERS } from '.';
import { DB_CourtCase } from './types/DB_CourtCase';
import { DB_MailLog } from './types/DB_MailLog';

let nextRunTimeout: NodeJS.Timeout | undefined = undefined;
const dayMs = ( 1000 * 60 * 60 * 24 );

let transporter: nodemailer.Transporter | null = null;

export type MailerConfig = {
    host: string, port: number,
    username?: string, password?: string,
    fromAddress: string,
    tlsAllowSelfSigned: boolean
}
export async function initMailer(mailConfig: MailerConfig): Promise<void> {
    let c = {
        host: mailConfig.host, port: mailConfig.port,
        secure: mailConfig.port === 456,
        tls: {
            rejectUnauthorized: !mailConfig.tlsAllowSelfSigned
        }
    }
    if (mailConfig.username || mailConfig.password) {
        (c as any).auth = {
            type: 'login',
            user: mailConfig.username,
            pass: mailConfig.password
        };
    }
    transporter = nodemailer.createTransport(c, {
        from: `AACE Court Watchdog <${mailConfig.fromAddress}>`
    });

    let msToNextRun = dayMs;
    try {
        clearTimeout(nextRunTimeout);
        const mailLogs = db().collection<DB_MailLog>(DB_COLLECTION_MAIL_LOGS);
        let lastRun = await mailLogs.findOne({ completed: true }, { sort: { $natural: -1 } });

        let msSinceLastRun = Date.now() - (lastRun?.timestamp.getTime() || 0); 
        msToNextRun = Math.max(0, ( 1000 * 60 * 60 * 24) - msSinceLastRun);
    } catch (err) {
        error("Failed to check last mail run time", err);
    }

    nextRunTimeout = setTimeout(runMailer, msToNextRun);
    info(`Next run scheduled for ${new Date(Date.now() + msToNextRun)}`);
    return testMailerConnection().catch(err => error('Connection test failed', err));
}

export function closeMailer() {
    clearTimeout(nextRunTimeout);
    transporter = null;
    info('Disabled');
}

export function isMailerInit(): boolean {
    return transporter !== null;
}

async function testMailerConnection(): Promise<void> {
    return new Promise((resolve, reject) => {
        if (!transporter) {
            reject({ name: 'MailerNotInitialized', message: 'Mailer has not been initialized' })
            return;
        };

        transporter.verify((err, success) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        })
    });
}

/**
 * Send an email to all subscribed users if any new 
 * cases have been added to the database since the last
 * mailer run.
 */
export async function runMailer(): Promise<void> {
    return new Promise(async (resolve, reject) => {
        const report: DB_MailLog = {
            completed: false,
            timestamp: new Date(),
            newestCase: new Date(0)
        }

        info('Running mailer');
        if (!transporter) {
            throw NoMailerError;
        }

        let newCaseCount = 0;
        let latestCase: DB_CourtCase;
        try {
            // Find previous run time
            const mailLogs = db().collection<DB_MailLog>(DB_COLLECTION_MAIL_LOGS);
            let lastRun = await mailLogs.findOne({ completed: true }, { sort: { $natural: -1 } });
            let fromDate = lastRun ? lastRun.newestCase : new Date(0);

            const cases = db().collection<DB_CourtCase>(DB_COLLECTION_CASES);
            const pipeline: Document[] = [
                { $addFields: { "localId": { $concat: ["$locationState", ".", "$id"] } } },
                {
                    $lookup: {
                        from: "case_reviews",
                        localField: "localId",
                        foreignField: "caseId",
                        as: "reviews"
                    }
                },
                { $match: { 'reviews.0': { $exists: false }, firstFound: { $gt: fromDate } } },
                {
                    $facet: {
                        "totalCount": [{ $count: 'total' }],
                        "cases": [
                            { $sort: { firstFound: -1 } },
                            { $limit: 1 },
                        ]
                    }
                }
            ];

            let results = (await cases.aggregate(pipeline).toArray())[0];
            newCaseCount = results.totalCount[0]?.total || 0;
            if (newCaseCount > 0) {
                latestCase = results.cases[0];
                report.newestCase = latestCase.firstFound;
            }
        } catch (err) {
            error('Failed to get new case count from database', err);
            return reject(err);
        }

        if (newCaseCount === 0) {
            info('No new cases since the last run');
            return;
        }

        const toAddresses: UserAccount[] = [];
        try {
            const users = db().collection<UserAccount>(DB_COLLECTION_USERS);
            let filter: Filter<UserAccount> = { email: { $exists: true } };

            let results = users.find(filter);
            await results.forEach(u => {
                if (u.email!.trim().length > 0) {
                    toAddresses.push(u);
                }
            });
        } catch (err) {
            error('Failed to get list of users from database', err);
            return reject(err);
        }

        const sentPromises: Promise<void>[] = [];

        for (let user of toAddresses) {
            let mailText = `Automatic alert from AACE Court Watchdog for ${user.name}:\n\n${newCaseCount} new cases that may involve an auditor have been discovered by the automatic search. Open the app to review them.\n\nTo unsubscribe from these messages, visit the settings page in the app.`;
            sentPromises.push(
                sendMail(mailText, user.email!, "Watchdog: New cases found")
            );
        }

        let results = await Promise.allSettled(sentPromises);
        let failedCount = 0;
        let succeededCount = 0;
        for (let r of results) {
            if (r.status === 'fulfilled') {
                succeededCount++;
            } else {
                failedCount++;
            }
        }
        if (succeededCount > 1) report.completed = true;
        info(`Emails sent. ${succeededCount} successes and ${failedCount} failures`);

        // Store a log of this run in the DB
        try {
            const mailLogs = db().collection<DB_MailLog>(DB_COLLECTION_MAIL_LOGS);
            mailLogs.insertOne(report);
        } catch (err) {
            error("Failed to store log of this run", err);
        }

        nextRunTimeout = setTimeout(runMailer, dayMs);
        info(`Next run scheduled for ${new Date(Date.now() + dayMs)}`);
    });
}

function sendMail(text: string, to: string, subject: string): Promise<void> {
    return new Promise((resolve, reject) => {
        if (!transporter) return reject();
        transporter.sendMail({
            to: to,
            subject: subject,
            text: text
        }, (err, info) => {
            if (err) {
                return reject(err);
            } else {
                return resolve();
            }
        });
    });
}

function info(s: string, other?: any) {
    if (other) {
        console.info('[Mailer] ' + s, other);
    } else {
        console.info('[Mailer] ' + s);
    }
}
function error(s: string, other?: any) {
    if (other) {
        console.error('[Mailer] ' + s, other);
    } else {
        console.error('[Mailer] ' + s);
    }
}
const NoMailerError = { name: 'MailerNotInitialized', message: 'Mailer has not been initialized' };