import { api, initWithServer } from './TestingUtils';
import { sayHello } from '../src/api/paths/hello';

describe('Hello endpoint', () => {

    const { expect, request } = initWithServer();

    it('should include my name in the greeting', () => {
        const name = "MICYCLE";
        const greeting = sayHello(name);

        expect(greeting).to.include(name);
    });

    it('should say hello over the HTTP endpoint', (done) => {
        const userName = "cassie";
        request(api)
         .get("/hello")
         .query({ name: userName })
         .send()
         .end((err, res) => {
            expect(res).to.have.status(200);
            expect(res.text).to.include(userName);
            done();
         })
    });

});