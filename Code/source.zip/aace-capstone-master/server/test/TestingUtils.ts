import { launch, ServerStuff } from '../src/index';
import chai from 'chai';
import chaiHttp from 'chai-http';
const path = require('path');

export function init(): TestingInit {
    return {
        expect: chai.expect 
    }
}

export function initWithServer(): TestingInitWithServer { 
    chai.use(chaiHttp);

    let s: ServerStuff;
    before(async function launchServer() {
        const mongoUrl = process.env.MONGO_URL || "mongodb://localhost:27017";
        s = await launch(3031, "test-aace-capstone", mongoUrl, path.join(__dirname, "../out/api/paths"));
        await s.startupDone;
        console.info('--- Server startup complete ---');
    });
    after(async function shutdownServer() {
        console.info('--- Closing server ---')
        if (s) await s.shutdown();
    });

    return {
       expect: chai.expect, request: chai.request,
    }
}

export const api = "http://localhost:3031/api";

export type TestingInit = {
    expect: Chai.ExpectStatic,
}

export type TestingInitWithServer = TestingInit & { request: Chai.ChaiHttpRequest };