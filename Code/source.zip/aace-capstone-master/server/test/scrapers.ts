import { AllScrapers } from '../src';
import { flushQLDCache } from '../src/scrape/QLDScraper';
import { ScraperSearchField, ScraperSearchResults } from '../src/scrape/Scraper';
import { api, init } from './TestingUtils';
import { isCourtCase } from '@aace/capstone-common/codegen/client/models/CourtCase.guard';

const { expect } = init();
const searchText = 'a';

describe("Scrapers", () => {
    Object.keys(AllScrapers).forEach((scraperKey) => {
        let { name, scraper } = AllScrapers[scraperKey];

        describe(name, () => {
            let basicR: ScraperSearchResults; 

            before(async () => {
                basicR = await scraper({ text: searchText, textField: ScraperSearchField.PartyPersonName, limit: 50 });
            });

            it("returns results", async () => {
                expect(basicR.results.length).to.be.greaterThan(0);
            });

            it("structures results as CourtCase objects", () => {
                expect(basicR.results.every(isCourtCase)).to.be.true;
            });

            it("doesn't have any NaNs or nulls", () => {
                expect(basicR.limit).to.not.be.NaN;
                expect(basicR.offset).to.not.be.NaN;
                expect(basicR.total).to.not.be.NaN;
                expect(basicR.limit).to.be.a('number');
                expect(basicR.offset).to.be.a('number');
                expect(basicR.total).to.be.a('number');
            });

            if (name !== 'NSW Online') {
                /**
                 * The NSW scraper is excluded from the duplicate tests, as it appears there
                 * is a bug with the NSW server that is responsible for the duplicates.
                 * This is present even on the website.
                 * We've confirmed via manual testing that our implementation adds no
                 * further duplicates. A fix on our end would be too complicated due to
                 * the paginated nature of the API.
                 */
                it("does not return duplicates", async () => {
                    let s = new Set<string>();
                    basicR.results.forEach(c => s.add(c.id));

                    expect(s.size).to.equal(basicR.results.length);
                });
            }

            // Pagination
            it("uses 0 as the default offset", async () => {
                expect(basicR.offset).to.equal(0);
            });

            it("respects pagination limit", async () => {
                const limit = 1;
                let r = await scraper({ text: searchText, textField: ScraperSearchField.PartyPersonName, limit: limit });

                expect(r.limit).to.equal(limit);
                expect(r.results.length).to.be.lessThanOrEqual(limit);
            });

            it("correctly indexes pages (overlap test)", async () => {
                let all = basicR.results;
                expect(all.length).to.be.greaterThan(0);

                let half = Math.floor(basicR.results.length / 2);
                let r = await scraper({ text: searchText, textField: ScraperSearchField.PartyPersonName, offset: half, limit: basicR.limit });

                // Results should be identical for the second half of the array
                let pageTwoFirstHalf = r.results.slice(0, half);
                let pageOneSecondHalf = all.slice(half);

                for (let i = 0; i < half; i++) {
                    expect(pageTwoFirstHalf[i].id).to.equal(pageOneSecondHalf[i].id);
                }

            });

        });
    });

    after(() => {
        flushQLDCache();
    })
})